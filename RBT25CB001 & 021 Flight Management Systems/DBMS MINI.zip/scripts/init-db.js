/* ============================================================================
   SkyLedger FMS - database initialiser for Node-only setups
   Usage:   npm run db:create
   ----------------------------------------------------------------------------
   Runs database/schema.sql using the credentials in .env. Handy when the mysql
   command-line client is not on your PATH (a common Windows problem).
   It uses multipleStatements:true because the whole .sql file is sent as one
   script - the DROP DATABASE at the top means all existing data is erased.
   ============================================================================ */

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const mysql = require('mysql2/promise');

const schemaPath = path.join(__dirname, '..', 'database', 'schema.sql');

async function ask(question) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const answer = await new Promise((resolve) => rl.question(question, resolve));
    rl.close();
    return answer.trim().toLowerCase();
}

(async () => {
    console.log('\n=== SkyLedger FMS - database initialiser ===\n');

    if (!fs.existsSync(schemaPath)) {
        console.error(`ERROR: ${schemaPath} not found.`);
        process.exit(1);
    }
    const sql = fs.readFileSync(schemaPath, 'utf8');
    console.log(`Script   : ${schemaPath}  (${(sql.length / 1024).toFixed(1)} KB)`);
    console.log(`Server   : ${process.env.DB_USER || 'root'}@${process.env.DB_HOST || '127.0.0.1'}:${process.env.DB_PORT || 3306}`);
    console.log(`Database : ${process.env.DB_NAME || 'flight_management_system'}\n`);

    const confirm = await ask('This DROPS and recreates the database (all bookings are erased). Continue? (y/N) ');
    if (confirm !== 'y') {
        console.log('Cancelled - nothing was changed.\n');
        process.exit(0);
    }

    let connection;
    try {
        connection = await mysql.createConnection({
            host: process.env.DB_HOST || '127.0.0.1',
            port: Number(process.env.DB_PORT || 3306),
            user: process.env.DB_USER || 'root',
            password: process.env.DB_PASSWORD || '',
            database: process.env.DB_NAME || 'flight_management_system',
            multipleStatements: true,          // the whole script is one call
            dateStrings: true
        });
        console.log('\nConnected. Executing schema.sql ...');

        await connection.query(sql);

        // Verify explicitly (cleaner than digging through multipleStatements results)
        const [counts] = await connection.query(
            `SELECT 'airport' AS table_name, COUNT(*) AS rows_loaded FROM airport
             UNION ALL SELECT 'airplane_company', COUNT(*) FROM airplane_company
             UNION ALL SELECT 'pilot',    COUNT(*) FROM pilot
             UNION ALL SELECT 'flight',   COUNT(*) FROM flight
             UNION ALL SELECT 'passenger',COUNT(*) FROM passenger
             UNION ALL SELECT 'booking',  COUNT(*) FROM booking
             UNION ALL SELECT 'ticket',   COUNT(*) FROM ticket
             UNION ALL SELECT 'payment',  COUNT(*) FROM payment`
        );
        console.log('\nRow counts loaded from database/schema.sql:');
        console.table(counts);

        console.log('\nDatabase created successfully.');
        console.log('Next step:  npm start   then open  http://localhost:' + (process.env.PORT || 3000) + '\n');
    } catch (err) {
        console.error('\nFAILED:', err.message);
        if (err.code === 'ER_ACCESS_DENIED_ERROR') {
            console.error('  -> wrong DB_USER / DB_PASSWORD in your .env file.');
        } else if (err.code === 'ECONNREFUSED') {
            console.error('  -> MySQL is not running. Start it (e.g. net start MySQL80).');
        } else if (err.code === 'ER_DBACCESS_DENIED_ERROR' || err.code === 'ER_ACCESS_DENIED_NO_PASSWORD_ERROR') {
            console.error('  -> your MySQL user may not have CREATE/DROP database privileges; run as root.');
        }
        process.exitCode = 1;
    } finally {
        if (connection) await connection.end();
    }
})();
