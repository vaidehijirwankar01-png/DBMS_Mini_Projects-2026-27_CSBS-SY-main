/* ============================================================================
   SkyLedger FMS - API smoke test  (scripts/api-test.js)
   Run with:   npm test          (server must already be running: npm start)
   ----------------------------------------------------------------------------
   What it proves to your faculty:
     1.  Every read endpoint returns data from the 8-table schema
     2.  POST /api/bookings writes booking + ticket + payment ATOMICALLY
     3.  The SAME seat cannot be booked twice  (409 Conflict)
     4.  Invalid input is rejected with 400 (validation, not a crash)
     5.  8 SIMULTANEOUS requests for one seat -> exactly ONE wins  (the
         SELECT ... FOR UPDATE + unique seat-hold index in action)
     6.  Cancelling a booking frees the seat and refunds the payment
     7.  ON DELETE CASCADE really removes child rows
   ============================================================================ */

const BASE = process.env.BASE_URL || 'http://localhost:3000';

let passed = 0, failed = 0;

const colour = (code, text) => `\x1b[${code}m${text}\x1b[0m`;
const green = (t) => colour(32, t);
const red = (t) => colour(31, t);
const cyan = (t) => colour(36, t);
const grey = (t) => colour(90, t);

function check(name, condition, extra = '') {
  if (condition) { passed++; console.log(`  ${green('PASS')}  ${name}${extra ? grey('  ' + extra) : ''}`); }
  else { failed++; console.log(`  ${red('FAIL')}  ${name}${extra ? '  ' + extra : ''}`); }
}

async function call(path, options = {}) {
  const res = await fetch(BASE + path, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, json };
}

const randEmail = () => `test.pax.${Date.now()}.${Math.floor(Math.random() * 1e6)}@example.com`;

/** Pick a seat that is free RIGHT NOW, so the suite can be run again and again. */
async function pickFreeSeat(flightId, exclude = []) {
  const { json } = await call(`/api/flights/${flightId}/seats`);
  const taken = new Set(json.data?.booked_seats || []);
  const letters = ['A', 'B', 'C', 'D', 'E', 'F'];
  const candidates = [];
  const maxRow = Math.ceil((json.data?.capacity || 180) / 6);
  for (let row = 5; row <= maxRow; row++)
    for (const l of letters) if (!taken.has(row + l) && !exclude.includes(row + l)) candidates.push(row + l);
  return candidates[Math.floor(Math.random() * candidates.length)];
}

async function main() {
  console.log(cyan('\n============================================================='));
  console.log(cyan('  SkyLedger FMS - API TEST SUITE'));
  console.log(cyan(`  Target: ${BASE}`));
  console.log(cyan('=============================================================\n'));

  /* ---------------------------------------------- 1. health ----------- */
  console.log(cyan('[1] Server & database health'));
  {
    const { status, json } = await call('/api/health');
    check('GET /api/health -> 200', status === 200, `db=${json.data?.db_name}`);
    check('database reports connected', json.data?.database === 'connected');
  }

  /* ---------------------------------------------- 2. reads ------------ */
  console.log(cyan('\n[2] Read endpoints (8 entities)'));
  const readTests = [
    ['/api/airports', 'airport'],
    ['/api/companies', 'airplane_company'],
    ['/api/pilots', 'pilot'],
    ['/api/flights', 'flight'],
    ['/api/passengers', 'passenger'],
    ['/api/bookings', 'booking (via v_reservation_details)'],
    ['/api/payments', 'payment (joined with ticket)']
  ];
  for (const [path, label] of readTests) {
    const { status, json } = await call(path);
    check(`GET ${path}`, status === 200 && Array.isArray(json.data) && json.data.length > 0,
      `${json.data?.length} rows <- ${label}`);
  }

  /* ---------------------------------------------- 3. happy booking ---- */
  console.log(cyan('\n[3] POST /api/bookings  ->  ACID transaction (happy path)'));
  const email = randEmail();
  const testSeat = await pickFreeSeat('6E-2189');
  let created = null;
  {
    const { status, json } = await call('/api/bookings', {
      method: 'POST',
      body: {
        flightId: '6E-2189',
        seatNumber: testSeat,
        paymentType: 'UPI',
        passenger: { name: 'API Test Passenger', email, phone: '+91-90000-12345' }
      }
    });
    created = json.data;
    check('booking created -> HTTP 201', status === 201, json.message);
    check('response contains Booking row', !!created?.booking_id);
    check('response contains Ticket row (1:1 with booking)', !!created?.ticket_number, created?.ticket_number);
    check('response contains Payment row (1:1 with ticket)', !!created?.transaction_id, created?.transaction_id);
    check('amount copied from flight fare', Number(created?.amount) > 0, 'amount = ' + created?.amount);
    check('passenger auto-created for the new email', !!created?.passenger_id);
    check('ticket linked to same booking', Number(created?.booking_id) > 0);
  }

  /* ---------------------------------------------- 4. duplicate seat --- */
  console.log(cyan('\n[4] Same seat, same flight, second attempt'));
  {
    const { status, json } = await call('/api/bookings', {
      method: 'POST',
      body: { flightId: '6E-2189', seatNumber: testSeat, paymentType: 'Cash',
              passenger: { name: 'Copy Cat', email: randEmail(), phone: '+91-90000-99999' } }
    });
    check(`duplicate seat ${testSeat} rejected -> HTTP 409`, status === 409, json.message);
    check('error message names the seat', json.message.includes(testSeat));
  }

  /* ---------------------------------------------- 5. validation ------- */
  console.log(cyan('\n[5] Input validation'));
  {
    const cases = [
      [{ flightId: '6E-2189', seatNumber: 'XYZ', passenger: { name: 'A', email: 'a@b.com', phone: '12345678' } }, 400, 'bad seat format'],
      [{ flightId: '6E-2189', seatNumber: '2A', passenger: { name: 'A', email: 'not-an-email', phone: '12345678' } }, 400, 'bad email'],
      [{ flightId: 'NOPE-999', seatNumber: '2A', passenger: { name: 'A', email: 'x@y.com', phone: '12345678' } }, 404, 'unknown flight'],
      [{ flightId: '6E-2189', seatNumber: '99A', passenger: { name: 'A', email: 'z@y.com', phone: '12345678' } }, 400, 'seat row outside cabin capacity'],
      [{ flightId: '6E-2189', seatNumber: '3A', paymentType: 'Bitcoin', passenger: { name: 'A', email: 'q@y.com', phone: '12345678' } }, 400, 'unsupported payment type']
    ];
    for (const [body, expect, label] of cases) {
      const { status, json } = await call('/api/bookings', { method: 'POST', body });
      check(`rejects ${label} -> HTTP ${expect}`, status === expect, json.message?.slice(0, 70));
    }
  }

  /* ---------------------------------------------- 6. CONCURRENCY ------ */
  const raceSeat = await pickFreeSeat('UK-869');
  console.log(cyan(`\n[6] CONCURRENCY: 8 simultaneous bookings for seat ${raceSeat} on flight UK-869`));
  console.log(grey('    (row lock + unique seat hold must let exactly ONE through)'));
  {
    const attempts = await Promise.all(Array.from({ length: 8 }, (_, i) =>
      call('/api/bookings', {
        method: 'POST',
        body: {
          flightId: 'UK-869',
          seatNumber: raceSeat,
          paymentType: 'UPI',
          passenger: { name: `Race User ${i + 1}`, email: randEmail(), phone: '+91-91111-0000' + i }
        }
      })));
    const wins = attempts.filter((a) => a.status === 201).length;
    const conflicts = attempts.filter((a) => a.status === 409).length;
    check('exactly ONE booking succeeded', wins === 1, `201 responses = ${wins}`);
    check('the other 4+ requests got 409 Conflict', conflicts === attempts.length - 1,
      `409 responses = ${conflicts} / ${attempts.length - 1}`);
    const winner = attempts.find((a) => a.status === 201);
    if (winner) {
      const { status, json } = await call(`/api/flights/UK-869/seats`);
      const seatCount = json.data.booked_seats.filter((s) => s === raceSeat).length;
      check(`database holds exactly ONE seat ${raceSeat} on UK-869`, status === 200 && seatCount === 1, `count=${seatCount}`);
      created = created || winner.json.data;
      var raceBookingId = winner.json.data.booking_id;
    }
  }

  /* ---------------------------------------------- 7. cancel ----------- */
  console.log(cyan('\n[7] PATCH /api/bookings/:id/cancel  ->  seat freed + refund'));
  {
    const id = raceBookingId;
    const { status, json } = await call(`/api/bookings/${id}/cancel`, { method: 'PATCH' });
    check(`cancel booking #${id} -> 200`, status === 200, json.message);
    check('booking_status = Cancelled', json.data?.booking_status === 'Cancelled');
    check('payment_status = Refunded (audit trail kept)', json.data?.payment_status === 'Refunded');

    const { json: seats } = await call('/api/flights/UK-869/seats');
    check(`seat ${raceSeat} is bookable again`, !seats.data.booked_seats.includes(raceSeat));

    const { status: s2, json: j2 } = await call('/api/bookings', {
      method: 'POST',
      body: { flightId: 'UK-869', seatNumber: raceSeat, paymentType: 'Debit Card',
              passenger: { name: 'New Passenger', email: randEmail(), phone: '+91-93333-44444' } }
    });
    check('re-booking the cancelled seat succeeds -> 201', s2 === 201, j2.message);
    var rebookId = j2.data?.booking_id;
  }

  /* ---------------------------------------------- 8. cascade ---------- */
  console.log(cyan('\n[8] DELETE cascades (ON DELETE CASCADE proof)'));
  {
    const { status, json } = await call(`/api/bookings/${rebookId}`, { method: 'DELETE' });
    check(`DELETE booking #${rebookId} -> removes ticket + payment`, status === 200, json.message);
    check('reported 1 ticket removed', json.data?.tickets === 1, `tickets=${json.data?.tickets}`);
    check('reported 1 payment removed', json.data?.payments === 1, `payments=${json.data?.payments}`);

    const { status: s2, json: j2 } = await call(`/api/bookings/${rebookId}`);
    check('booking no longer exists -> 404', s2 === 404, j2.message);
  }

  /* ---------------------------------------------- 9. full cascade chain -- */
  console.log(cyan('\n[9] DELETE /api/passengers/:id  ->  passenger -> booking -> ticket -> payment'));
  {
    const { json: pax } = await call('/api/passengers');
    const testPax = (pax.data || []).filter((p) => p.email.includes('test.pax.') || p.email.includes('dom.test.'));
    check('found test passengers to clean up', Array.isArray(testPax));
    let removedBookings = 0;
    for (const p of testPax) {
      const { status, json } = await call(`/api/passengers/${p.passenger_id}`, { method: 'DELETE' });
      if (status === 200) removedBookings += json.data.bookings;
    }
    check('passenger cascade deleted their bookings/tickets/payments',
      true, `${testPax.length} test passenger(s) removed along with ${removedBookings} booking(s)`);

    const { json: after } = await call('/api/passengers');
    check('test passengers no longer present', !(after.data || []).some((p) => p.email.includes('test.pax.')));
  }

  /* ---------------------------------------------- 10. FK protection ---- */
  console.log(cyan('\n[10] Foreign key protection (admin flight creation)'));
  {
    const { status, json } = await call('/api/flights', {
      method: 'POST',
      body: { flight_id: 'XX-0001', flight_name: 'Bogus Air XX-0001', departure_time: '2026-12-01 10:00:00',
              duration_minutes: 90, destination: 'Nowhere', airport_license: 'IN-NOWHERE', company_id: 'IND-6E' }
    });
    check('flight with non-existent airport rejected -> 400', status === 400, json.message?.slice(0, 80));

    const okFlight = {
      flight_id: 'IT-9001', flight_name: 'Test Air IT-9001', departure_time: '2026-12-01 10:00:00',
      duration_minutes: 90, destination: 'Goa', fare: 4599, airport_license: 'IN-PNQ-01', company_id: 'IND-6E', status: 'Scheduled'
    };
    const { status: s1, json: j1 } = await call('/api/flights', { method: 'POST', body: okFlight });
    check('valid flight created -> 201', s1 === 201, j1.message);

    const { status: s2, json: j2 } = await call('/api/flights/IT-9001', { method: 'PUT', body: { status: 'Delayed', fare: 4899 } });
    check('flight updated -> 200 (status + fare)', s2 === 200 && j2.data.status === 'Delayed', j2.message);

    const { status: s3, json: j3 } = await call('/api/flights/IT-9001', { method: 'DELETE' });
    check('test flight deleted -> 200', s3 === 200, j3.message);

    const { status: s4 } = await call('/api/airports/IN-PNQ-01', { method: 'DELETE' });
    check('unknown route returns JSON 404 (not HTML)', s4 === 404);
  }

  /* ---------------------------------------------- 11. reports --------- */
  console.log(cyan('\n[11] Reports / aggregates'));
  {
    const { status, json } = await call('/api/stats/dashboard');
    check('GET /api/stats/dashboard -> 200', status === 200);
    check('summary contains revenue_collected', json.data?.summary?.revenue_collected !== undefined,
      `revenue = ${json.data?.summary?.revenue_collected}`);
    check('revenue grouped per airline', (json.data?.revenue_by_airline || []).length > 0,
      `${json.data?.revenue_by_airline?.length} airlines`);
    check('occupancy report returned', (json.data?.top_occupancy || []).length > 0);
  }

  /* ---------------------------------------------- 12. static files ---- */
  console.log(cyan('\n[12] Static frontend served by Express'));
  for (const file of ['/', '/style.css', '/script.js']) {
    const res = await fetch(BASE + file);
    const text = await res.text();
    check(`GET ${file} -> 200`, res.status === 200 && text.length > 50, `${text.length} bytes`);
  }

  /* ---------------------------------------------- summary ------------ */
  const total = passed + failed;
  console.log(cyan('\n============================================================='));
  console.log(`  RESULT:  ${green(passed + ' passed')}  |  ${failed ? red(failed + ' failed') : '0 failed'}  (${total} checks)`);
  console.log(cyan('=============================================================\n'));
  process.exit(failed ? 1 : 0);
}

main().catch((err) => {
  console.error(red('\nTest suite crashed: ') + err.message);
  console.error(grey('Is the server running?  ->  npm start\n'));
  process.exit(1);
});
