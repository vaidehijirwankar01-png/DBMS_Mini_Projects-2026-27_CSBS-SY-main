/* ============================================================================
   FLIGHT MANAGEMENT SYSTEM (FMS)  --  Backend / REST API server
   File   : server.js
   Run    : npm start        (or)  npm run dev   [nodemon, auto-restart]
   Node   : v18 or higher        Database : MySQL 8 / MariaDB 10.4+
   ----------------------------------------------------------------------------
   ARCHITECTURE (keep this in mind while explaining the project):

     Browser (public/index.html + script.js)
          |  fetch() -> JSON over HTTP  (REST)
          v
     Express app (this file)   ->  validation + business rules
          |  SQL with placeholders (prepared statements)
          v
     mysql2 connection POOL
          |  BEGIN / COMMIT / ROLLBACK  (ACID)
          v
     MySQL database flight_management_system  (8 tables + 3 views)

   API GROUPS
     /api/health                 - server + database status
     /api/airports               - read airports
     /api/companies              - read airline companies (+ fleet stats)
     /api/pilots                 - read pilots with their company
     /api/flights                - search flights, CRUD (admin)
     /api/passengers             - register / list passengers
     /api/bookings               - *** ACID transaction: seat booking ***
     /api/tickets, /api/payments - ticket & payment lookups
     /api/reports, /api/stats    - aggregates for the dashboard
   ============================================================================ */

'use strict';

require('dotenv').config();

const path = require('path');
const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const morgan = require('morgan');

const app = express();
const PORT = Number(process.env.PORT || 3000);

/* ---------------------------------------------------------------------------
   1. DATABASE CONNECTION POOL
   A pool keeps a set of reusable connections, which is far better than
   opening a new connection for every HTTP request.
   --------------------------------------------------------------------------- */
const pool = mysql.createPool({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'flight_management_system',
    waitForConnections: true,
    connectionLimit: Number(process.env.DB_POOL_SIZE || 10),
    queueLimit: 0,
    dateStrings: true,      // DATETIME -> 'YYYY-MM-DD HH:MM:SS' (no timezone surprises)
    decimalNumbers: true    // DECIMAL  -> JavaScript number (fare, amount)
});

/* ---------------------------------------------------------------------------
   2. SMALL HELPERS  (validation, errors, transaction runner)
   --------------------------------------------------------------------------- */
const PAYMENT_TYPES = ['UPI', 'Credit Card', 'Debit Card', 'Net Banking', 'Wallet', 'Cash'];
const FLIGHT_STATUSES = ['Scheduled', 'Delayed', 'Departed', 'Arrived', 'Cancelled'];
const SEAT_RE = /^[0-9]{1,2}[A-F]$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE_RE = /^[+0-9][0-9\-\s]{7,19}$/;

class HttpError extends Error {
    constructor(status, message, details) {
        super(message);
        this.status = status;
        this.details = details;
    }
}

/** Wraps an async route so any thrown error reaches the error middleware. */
const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

/**
 * The heart of data integrity: run `work(connection)` inside one SQL
 * transaction. COMMIT on success, ROLLBACK on any error, always release the
 * connection back to the pool.
 */
async function withTransaction(work) {
    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction();
        const result = await work(conn);
        await conn.commit();
        return result;
    } catch (err) {
        try { await conn.rollback(); } catch (_) { /* nothing we can do */ }
        throw err;
    } finally {
        conn.release();
    }
}

const ymd = (d = new Date()) =>
    `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;

/** Terminal is auto-assigned by operator (real systems get it from airport slot data). */
function pickTerminal(companyId) {
    const map = { 'IND-6E': 'T1', 'AIC-AI': 'T3', 'VTI-UK': 'T2', 'UAE-EK': 'T3', 'SIA-SQ': 'T1' };
    return map[companyId] || 'T1';
}

const ok = (res, data, message = 'OK') => res.json({ success: true, message, data });

/* ---------------------------------------------------------------------------
   3. MIDDLEWARE
   --------------------------------------------------------------------------- */
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use(cors());
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));   // serves the dashboard

/* ---------------------------------------------------------------------------
   4. ROUTES
   --------------------------------------------------------------------------- */

/* ---- 4.1 Health check ------------------------------------------------- */
app.get('/api/health', asyncHandler(async (req, res) => {
    const [[row]] = await pool.query('SELECT NOW() AS db_time, DATABASE() AS db_name, VERSION() AS db_version');
    ok(res, { server: 'up', database: 'connected', ...row, uptime_seconds: Math.round(process.uptime()) });
}));

/* ---- 4.2 Airports ----------------------------------------------------- */
app.get('/api/airports', asyncHandler(async (req, res) => {
    const { type, country, city } = req.query;
    const where = [];
    const params = [];
    if (type)    { where.push('type = ?');          params.push(type); }
    if (country) { where.push('country = ?');       params.push(country); }
    if (city)    { where.push('city LIKE ?');       params.push(`%${city}%`); }

    const [rows] = await pool.query(
        `SELECT a.*, (SELECT COUNT(*) FROM flight f WHERE f.airport_license = a.airport_license) AS flights_operated
           FROM airport a
           ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
          ORDER BY a.city`,
        params
    );
    ok(res, rows, `${rows.length} airport(s) found`);
}));

/* ---- 4.3 Airline companies -------------------------------------------- */
app.get('/api/companies', asyncHandler(async (req, res) => {
    const [rows] = await pool.query(
        `SELECT c.*,
                (SELECT COUNT(*) FROM pilot  p WHERE p.company_id = c.company_id) AS total_pilots,
                (SELECT COUNT(*) FROM flight f WHERE f.company_id = c.company_id) AS total_flights
           FROM airplane_company c
          ORDER BY c.company_name`
    );
    ok(res, rows, `${rows.length} company(ies) found`);
}));

/* ---- 4.4 Pilots -------------------------------------------------------- */
app.get('/api/pilots', asyncHandler(async (req, res) => {
    const { company_id, role } = req.query;
    const where = [];
    const params = [];
    if (company_id) { where.push('pl.company_id = ?'); params.push(company_id); }
    if (role)       { where.push('pl.role = ?');       params.push(role); }

    const [rows] = await pool.query(
        `SELECT pl.pilot_license, pl.pilot_name, pl.contact_number, pl.role, pl.age,
                pl.date_of_birth, pl.experience, pl.company_id,
                c.company_name, c.model
           FROM pilot pl
           LEFT JOIN airplane_company c ON c.company_id = pl.company_id
           ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
          ORDER BY pl.experience DESC, pl.pilot_name`,
        params
    );
    ok(res, rows, `${rows.length} pilot(s) found`);
}));

/* ---- 4.5 Flights : search / list -------------------------------------- */
/*  GET /api/flights?source=IN-PNQ-01&destination=Pune&status=Scheduled
                    &date=2026-10-15&q=IndiGo&limit=50                       */
app.get('/api/flights', asyncHandler(async (req, res) => {
    const { source, destination, status, date, q, limit } = req.query;
    const where = [];
    const params = [];

    if (source)      { where.push('airport_license = ?');                    params.push(source); }
    if (destination) { where.push('(destination LIKE ? OR source_city LIKE ?)'); params.push(`%${destination}%`, `%${destination}%`); }
    if (status)      { where.push('status = ?');                            params.push(status); }
    if (date)        { where.push('DATE(departure_time) = ?');              params.push(date); }
    if (q)           { where.push('(flight_id LIKE ? OR flight_name LIKE ? OR company_name LIKE ?)');
                       params.push(`%${q}%`, `%${q}%`, `%${q}%`); }

    const max = Math.min(Number(limit) || 100, 500);
    const [rows] = await pool.query(
        `SELECT * FROM v_flight_schedule
          ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
          ORDER BY departure_time
          LIMIT ${max}`,                       // `max` is a safe integer, not user text
        params
    );
    ok(res, rows, `${rows.length} flight(s) found`);
}));

/* ---- 4.6 Flights : single flight + seat availability ------------------ */
app.get('/api/flights/:flightId', asyncHandler(async (req, res) => {
    const [rows] = await pool.query('SELECT * FROM v_flight_schedule WHERE flight_id = ?', [req.params.flightId]);
    if (!rows.length) throw new HttpError(404, `Flight ${req.params.flightId} not found`);
    ok(res, rows[0]);
}));

app.get('/api/flights/:flightId/seats', asyncHandler(async (req, res) => {
    const flightId = req.params.flightId;
    const [f] = await pool.query('SELECT * FROM v_flight_schedule WHERE flight_id = ?', [flightId]);
    if (!f.length) throw new HttpError(404, `Flight ${flightId} not found`);

    const [booked] = await pool.query(
        `SELECT seat_number, booking_status
           FROM booking
          WHERE flight_id = ? AND booking_status <> 'Cancelled'
          ORDER BY seat_number`,
        [flightId]
    );
    ok(res, {
        flight_id: flightId,
        capacity: f[0].capacity,
        seats_available: f[0].seats_available,
        booked_seats: booked.map((r) => r.seat_number)
    });
}));

/* ---- 4.7 Flights : admin CRUD ----------------------------------------- */
app.post('/api/flights', asyncHandler(async (req, res) => {
    const b = req.body || {};
    const required = ['flight_id', 'flight_name', 'departure_time', 'duration_minutes',
                      'destination', 'airport_license', 'company_id'];
    const missing = required.filter((k) => b[k] === undefined || b[k] === '');
    if (missing.length) throw new HttpError(400, 'Missing required field(s)', missing);
    if (b.status && !FLIGHT_STATUSES.includes(b.status)) throw new HttpError(400, 'Invalid status');
    if (!(Number(b.duration_minutes) > 0)) throw new HttpError(400, 'duration_minutes must be a positive number');

    await pool.query(
        `INSERT INTO flight (flight_id, flight_name, departure_time, duration_minutes,
                             status, destination, fare, airport_license, company_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [b.flight_id, b.flight_name, b.departure_time.replace('T', ' '), Number(b.duration_minutes),
         b.status || 'Scheduled', b.destination, Number(b.fare || 0), b.airport_license, b.company_id]
    );
    const [rows] = await pool.query('SELECT * FROM v_flight_schedule WHERE flight_id = ?', [b.flight_id]);
    res.status(201).json({ success: true, message: `Flight ${b.flight_id} created`, data: rows[0] });
}));

app.put('/api/flights/:flightId', asyncHandler(async (req, res) => {
    const b = req.body || {};
    const fields = [];
    const params = [];
    const allowed = { flight_name: 'string', departure_time: 'string', duration_minutes: 'number',
                      status: 'string', destination: 'string', fare: 'number',
                      airport_license: 'string', company_id: 'string' };

    for (const [key, type] of Object.entries(allowed)) {
        if (b[key] === undefined) continue;
        if (b[key] === null || b[key] === '') throw new HttpError(400, `${key} cannot be empty`);
        if (type === 'number' && !(Number(b[key]) >= 0)) throw new HttpError(400, `${key} must be a number`);
        if (key === 'status' && !FLIGHT_STATUSES.includes(b[key])) throw new HttpError(400, 'Invalid status');
        fields.push(`${key} = ?`);
        params.push(type === 'number' ? Number(b[key]) : String(b[key]).replace('T', ' '));
    }
    if (!fields.length) throw new HttpError(400, 'No updatable field supplied');

    params.push(req.params.flightId);
    const [result] = await pool.query(`UPDATE flight SET ${fields.join(', ')} WHERE flight_id = ?`, params);
    if (!result.affectedRows) throw new HttpError(404, `Flight ${req.params.flightId} not found`);

    const [rows] = await pool.query('SELECT * FROM v_flight_schedule WHERE flight_id = ?', [req.params.flightId]);
    ok(res, rows[0], `Flight ${req.params.flightId} updated`);
}));

app.delete('/api/flights/:flightId', asyncHandler(async (req, res) => {
    // ON DELETE CASCADE on booking.flight_id means the flight's bookings (and
    // their tickets/payments) are removed automatically - we report the count.
    const [[counts]] = await pool.query(
        `SELECT (SELECT COUNT(*) FROM booking WHERE flight_id = ?) AS bookings_removed`,
        [req.params.flightId]
    );
    const [result] = await pool.query('DELETE FROM flight WHERE flight_id = ?', [req.params.flightId]);
    if (!result.affectedRows) throw new HttpError(404, `Flight ${req.params.flightId} not found`);
    ok(res, { flight_id: req.params.flightId, ...counts },
       `Flight deleted. Cascading delete removed ${counts.bookings_removed} booking(s) and their tickets/payments.`);
}));

/* ---- 4.8 Passengers ---------------------------------------------------- */
app.get('/api/passengers', asyncHandler(async (req, res) => {
    const { email } = req.query;
    const [rows] = await pool.query(
        `SELECT p.passenger_id, p.passenger_name, p.email, p.phone_number,
                (SELECT COUNT(*) FROM booking b WHERE b.passenger_id = p.passenger_id) AS total_bookings
           FROM passenger p
          ${email ? 'WHERE p.email = ?' : ''}
          ORDER BY p.passenger_id`,
        email ? [email] : []
    );
    ok(res, rows, `${rows.length} passenger(s) found`);
}));

app.post('/api/passengers', asyncHandler(async (req, res) => {
    const { passenger_name, email, phone_number } = req.body || {};
    if (!passenger_name || !email || !phone_number) throw new HttpError(400, 'passenger_name, email and phone_number are required');
    if (!EMAIL_RE.test(email)) throw new HttpError(400, 'Invalid email address');
    if (!PHONE_RE.test(phone_number)) throw new HttpError(400, 'Invalid phone number');

    const [dup] = await pool.query('SELECT passenger_id FROM passenger WHERE email = ?', [email]);
    if (dup.length) throw new HttpError(409, `A passenger with email ${email} already exists`, { passenger_id: dup[0].passenger_id });

    const [r] = await pool.query(
        'INSERT INTO passenger (passenger_name, email, phone_number) VALUES (?, ?, ?)',
        [passenger_name, email, phone_number]
    );
    res.status(201).json({ success: true, message: 'Passenger registered',
        data: { passenger_id: r.insertId, passenger_name, email, phone_number } });
}));

/* ---- 4.9 *** BOOKING CREATION : the ACID TRANSACTION *** --------------
   Steps inside ONE transaction (all succeed, or nothing is saved):

     1. SELECT ... FOR UPDATE  the flight row  -> locks it, serialises
        concurrent bookings of the same flight
     2. Business rules: flight not cancelled / not already departed,
        seat within cabin capacity, seat not already taken
     3. Resolve the passenger (reuse by email, or INSERT a new one)
     4. INSERT the booking row  -> generates booking_id
     5. INSERT the ticket row   -> ticket_number, boarding_time = departure - 45 min
     6. INSERT the payment row  -> transaction_id, amount = flight fare
     7. COMMIT  (ROLLBACK automatically on ANY error, e.g. duplicate seat)
   ---------------------------------------------------------------------- */
app.post('/api/bookings', asyncHandler(async (req, res) => {
    const body = req.body || {};
    const flightId = (body.flightId || '').trim();
    const seatNumber = String(body.seatNumber || '').trim().toUpperCase();
    const paymentType = body.paymentType || 'UPI';
    const passengerId = body.passengerId ? Number(body.passengerId) : null;
    const p = body.passenger || {};

    /* ---- input validation (fail fast, before touching the database) ---- */
    if (!flightId) throw new HttpError(400, 'flightId is required');
    if (!SEAT_RE.test(seatNumber)) throw new HttpError(400, 'seatNumber must be like 12A (row 1-99 + letter A-F)');
    if (!PAYMENT_TYPES.includes(paymentType)) throw new HttpError(400, `paymentType must be one of: ${PAYMENT_TYPES.join(', ')}`);
    if (!passengerId) {
        if (!p.name || !p.email || !p.phone) throw new HttpError(400, 'Provide passengerId, or passenger {name, email, phone}');
        if (!EMAIL_RE.test(p.email)) throw new HttpError(400, 'Invalid passenger email');
        if (!PHONE_RE.test(p.phone)) throw new HttpError(400, 'Invalid passenger phone number');
    }

    const summary = await withTransaction(async (conn) => {

        /* STEP 1 - lock the flight row so two users cannot grab the same seat */
        const [flights] = await conn.query(
            `SELECT f.flight_id, f.flight_name, f.departure_time, f.status, f.destination,
                    f.fare, f.airport_license, c.capacity, c.company_name
               FROM flight f
               JOIN airplane_company c ON c.company_id = f.company_id
              WHERE f.flight_id = ?
              FOR UPDATE`,
            [flightId]
        );
        if (!flights.length) throw new HttpError(404, `Flight ${flightId} not found`);
        const flight = flights[0];

        /* STEP 2 - business rules */
        if (flight.status === 'Cancelled') throw new HttpError(409, `Flight ${flightId} has been cancelled`);
        if (flight.status === 'Departed' || flight.status === 'Arrived')
            throw new HttpError(409, `Booking closed: flight ${flightId} has already ${flight.status.toLowerCase()}`);
        // Ask the DATABASE for its own clock/date (timezone-safe, no client trust):
        const [[clock]] = await conn.query('SELECT NOW() AS db_now, (? <= NOW()) AS already_departed', [flight.departure_time]);
        if (clock.already_departed)
            throw new HttpError(409, `Booking closed: flight ${flightId} departed at ${flight.departure_time}`);

        const maxRow = Math.ceil(flight.capacity / 6);
        if (Number(seatNumber.replace(/[A-F]/, '')) > maxRow)
            throw new HttpError(400, `Seat ${seatNumber} is outside the cabin (this aircraft has rows 1-${maxRow})`);

        const [taken] = await conn.query(
            `SELECT booking_id FROM booking
              WHERE flight_id = ? AND seat_number = ? AND booking_status <> 'Cancelled'
              FOR UPDATE`,
            [flightId, seatNumber]
        );
        if (taken.length) throw new HttpError(409, `Seat ${seatNumber} on flight ${flightId} is already booked`);

        /* STEP 3 - resolve passenger (reuse existing email, else create) */
        let passenger;
        if (passengerId) {
            const [rows] = await conn.query(
                'SELECT passenger_id, passenger_name, email, phone_number FROM passenger WHERE passenger_id = ? FOR UPDATE',
                [passengerId]
            );
            if (!rows.length) throw new HttpError(404, `Passenger ${passengerId} not found`);
            passenger = rows[0];
        } else {
            const [rows] = await conn.query(
                'SELECT passenger_id, passenger_name, email, phone_number FROM passenger WHERE email = ? FOR UPDATE',
                [p.email]
            );
            if (rows.length) {
                passenger = rows[0];
            } else {
                const [ins] = await conn.query(
                    'INSERT INTO passenger (passenger_name, email, phone_number) VALUES (?, ?, ?)',
                    [p.name.trim(), p.email.trim().toLowerCase(), p.phone.trim()]
                );
                passenger = { passenger_id: ins.insertId, passenger_name: p.name.trim(), email: p.email.trim(), phone_number: p.phone.trim() };
            }
        }

        /* STEP 4 - booking row (seat_hold generated column + UNIQUE key is the
                    last line of defence against double booking) */
        const [bookingIns] = await conn.query(
            `INSERT INTO booking (seat_number, booking_status, booking_date, passenger_id, flight_id)
             VALUES (?, 'Confirmed', NOW(), ?, ?)`,
            [seatNumber, passenger.passenger_id, flightId]
        );
        const bookingId = bookingIns.insertId;

        /* STEP 5 - ticket row */
        const [[seq]] = await conn.query(
            `SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(ticket_number, '-', -1) AS UNSIGNED)), 0) + 1 AS next_seq
               FROM ticket WHERE ticket_number LIKE ?`,
            [`TKT-${ymd()}-%`]
        );
        const ticketNumber = `TKT-${ymd()}-${String(seq.next_seq).padStart(4, '0')}`;

        await conn.query(
            `INSERT INTO ticket (ticket_number, boarding_time, terminal, seat_number, booking_id)
             VALUES (?, DATE_SUB(?, INTERVAL 45 MINUTE), ?, ?, ?)`,
            [ticketNumber, flight.departure_time, pickTerminal(flight.company_id || 'IND-6E'), seatNumber, bookingId]
        );

        /* STEP 6 - payment row */
        const txnId = `TXN-${ymd()}-${String(seq.next_seq).padStart(4, '0')}`;
        await conn.query(
            `INSERT INTO payment (transaction_id, payment_type, payment_date, amount, payment_status, ticket_number)
             VALUES (?, ?, NOW(), ?, 'Success', ?)`,
            [txnId, paymentType, flight.fare, ticketNumber]
        );

        return { bookingId, ticketNumber, transactionId: txnId, passengerId: passenger.passenger_id, seatNumber, flightId };
    });

    /* Read back the saved reservation through the 4-table view */
    const [row] = await pool.query('SELECT * FROM v_reservation_details WHERE booking_id = ?', [summary.bookingId]);

    res.status(201).json({
        success: true,
        message: `Booking confirmed. Ticket ${summary.ticketNumber} issued.`,
        data: row[0],
        transaction: {
            note: 'Committed atomically: booking + ticket + payment were saved in ONE transaction.',
            ...summary
        }
    });
}));

/* ---- 4.10 Bookings : list / read -------------------------------------- */
app.get('/api/bookings', asyncHandler(async (req, res) => {
    const { email, passengerId, flightId, status, limit } = req.query;
    const where = [];
    const params = [];
    if (email)       { where.push('email = ?');            params.push(email); }
    if (passengerId) { where.push('passenger_id = ?');     params.push(Number(passengerId)); }
    if (flightId)    { where.push('flight_id = ?');        params.push(flightId); }
    if (status)      { where.push('booking_status = ?');   params.push(status); }

    const max = Math.min(Number(limit) || 100, 500);
    const [rows] = await pool.query(
        `SELECT * FROM v_reservation_details
          ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
          ORDER BY booking_date DESC
          LIMIT ${max}`,
        params
    );
    ok(res, rows, `${rows.length} reservation(s) found`);
}));

app.get('/api/bookings/:bookingId', asyncHandler(async (req, res) => {
    const [rows] = await pool.query('SELECT * FROM v_reservation_details WHERE booking_id = ?', [req.params.bookingId]);
    if (!rows.length) throw new HttpError(404, `Booking ${req.params.bookingId} not found`);
    ok(res, rows[0]);
}));

/* ---- 4.11 Booking cancellation : transaction #2 ------------------------ */
app.patch('/api/bookings/:bookingId/cancel', asyncHandler(async (req, res) => {
    const result = await withTransaction(async (conn) => {
        const [bookings] = await conn.query(
            `SELECT b.booking_id, b.booking_status, b.flight_id, f.status AS flight_status, f.departure_time
               FROM booking b JOIN flight f ON f.flight_id = b.flight_id
              WHERE b.booking_id = ? FOR UPDATE`,
            [req.params.bookingId]
        );
        if (!bookings.length) throw new HttpError(404, `Booking ${req.params.bookingId} not found`);
        const b = bookings[0];
        if (b.booking_status === 'Cancelled') throw new HttpError(409, 'Booking is already cancelled');
        if (b.flight_status === 'Departed' || b.flight_status === 'Arrived')
            throw new HttpError(409, `Cannot cancel: flight ${b.flight_id} has already ${b.flight_status.toLowerCase()}`);

        await conn.query(`UPDATE booking SET booking_status = 'Cancelled' WHERE booking_id = ?`, [b.booking_id]);
        // Mark the payment as Refunded (kept for audit) - seat is freed via seat_hold = NULL
        const [refund] = await conn.query(
            `UPDATE payment pay
               JOIN ticket t ON t.ticket_number = pay.ticket_number
                SET pay.payment_status = 'Refunded'
              WHERE t.booking_id = ?`,
            [b.booking_id]
        );
        return { bookingId: b.booking_id, seat: b.seat_number, refunded: refund.affectedRows };
    });

    const [row] = await pool.query('SELECT * FROM v_reservation_details WHERE booking_id = ?', [result.bookingId]);
    ok(res, row[0], `Booking ${result.bookingId} cancelled. Refund initiated for ${result.refunded} payment(s).`);
}));

/* ---- 4.12 Booking hard delete (demonstrates ON DELETE CASCADE) -------- */
app.delete('/api/bookings/:bookingId', asyncHandler(async (req, res) => {
    const id = req.params.bookingId;
    const [[before]] = await pool.query(
        `SELECT (SELECT COUNT(*) FROM ticket t WHERE t.booking_id = b.booking_id) AS tickets,
                (SELECT COUNT(*) FROM payment p JOIN ticket t2 ON t2.ticket_number = p.ticket_number
                  WHERE t2.booking_id = b.booking_id) AS payments
           FROM booking b WHERE b.booking_id = ?`,
        [id]
    );
    const [result] = await pool.query('DELETE FROM booking WHERE booking_id = ?', [id]);
    if (!result.affectedRows) throw new HttpError(404, `Booking ${id} not found`);
    ok(res, { booking_id: Number(id), ...before },
       `Booking deleted. CASCADE removed ${before.tickets} ticket(s) and ${before.payments} payment(s).`);
}));

/* ---- 4.13 Tickets & payments ------------------------------------------ */
app.get('/api/tickets/:ticketNumber', asyncHandler(async (req, res) => {
    const [rows] = await pool.query(
        `SELECT t.ticket_number, t.boarding_time, t.terminal, t.seat_number,
                b.booking_id, b.booking_status, b.booking_date,
                p.passenger_name, p.email, p.phone_number,
                f.flight_id, f.flight_name, f.departure_time, f.destination, f.status AS flight_status,
                a.city AS source_city, a.airport_name AS source_airport,
                c.company_name, c.model
           FROM ticket t
           JOIN booking b           ON b.booking_id    = t.booking_id
           JOIN passenger p         ON p.passenger_id  = b.passenger_id
           JOIN flight f            ON f.flight_id     = b.flight_id
           JOIN airport a           ON a.airport_license = f.airport_license
           JOIN airplane_company c  ON c.company_id    = f.company_id
          WHERE t.ticket_number = ?`,
        [req.params.ticketNumber]
    );
    if (!rows.length) throw new HttpError(404, `Ticket ${req.params.ticketNumber} not found`);
    ok(res, rows[0]);
}));

app.get('/api/payments', asyncHandler(async (req, res) => {
    const { status, payment_type, limit } = req.query;
    const where = [];
    const params = [];
    if (status)       { where.push('pay.payment_status = ?'); params.push(status); }
    if (payment_type) { where.push('pay.payment_type = ?');   params.push(payment_type); }

    const max = Math.min(Number(limit) || 100, 500);
    const [rows] = await pool.query(
        `SELECT pay.transaction_id, pay.payment_type, pay.payment_date, pay.amount, pay.payment_status,
                t.ticket_number, t.seat_number, t.terminal,
                b.booking_id, b.booking_status,
                p.passenger_name, p.email,
                f.flight_id, f.flight_name, f.departure_time, f.destination
           FROM payment pay
           JOIN ticket t    ON t.ticket_number = pay.ticket_number
           JOIN booking b   ON b.booking_id    = t.booking_id
           JOIN passenger p ON p.passenger_id  = b.passenger_id
           JOIN flight f    ON f.flight_id     = b.flight_id
          ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
          ORDER BY pay.payment_date DESC
          LIMIT ${max}`,
        params
    );
    ok(res, rows, `${rows.length} payment(s) found`);
}));

/* ---- 4.14 Dashboard statistics & reports ------------------------------ */
app.get('/api/stats/dashboard', asyncHandler(async (req, res) => {
    const [[row]] = await pool.query(
        `SELECT
            (SELECT COUNT(*) FROM flight)                                                  AS total_flights,
            (SELECT COUNT(*) FROM flight WHERE status = 'Scheduled')                       AS scheduled_flights,
            (SELECT COUNT(*) FROM flight WHERE DATE(departure_time) = CURDATE())            AS flights_today,
            (SELECT COUNT(*) FROM airport)                                                 AS total_airports,
            (SELECT COUNT(*) FROM airplane_company)                                        AS total_companies,
            (SELECT COUNT(*) FROM pilot)                                                   AS total_pilots,
            (SELECT COUNT(*) FROM passenger)                                               AS total_passengers,
            (SELECT COUNT(*) FROM booking WHERE booking_status <> 'Cancelled')              AS active_bookings,
            (SELECT COUNT(*) FROM booking WHERE booking_status = 'Cancelled')               AS cancelled_bookings,
            (SELECT COALESCE(SUM(seats_available), 0) FROM v_flight_schedule
              WHERE status IN ('Scheduled','Delayed'))                                      AS seats_available,
            (SELECT COALESCE(SUM(amount), 0) FROM payment WHERE payment_status = 'Success') AS revenue_collected,
            (SELECT COALESCE(SUM(amount), 0) FROM payment WHERE payment_status = 'Refunded')AS revenue_refunded`
    );
    const [revenueByAirline] = await pool.query(
        `SELECT c.company_name, c.model,
                COUNT(DISTINCT f.flight_id)   AS flights,
                COUNT(DISTINCT b.booking_id)  AS bookings,
                COALESCE(SUM(pay.amount), 0)  AS revenue
           FROM airplane_company c
           LEFT JOIN flight  f   ON f.company_id = c.company_id
           LEFT JOIN booking b   ON b.flight_id  = f.flight_id AND b.booking_status <> 'Cancelled'
           LEFT JOIN ticket  t   ON t.booking_id = b.booking_id
           LEFT JOIN payment pay ON pay.ticket_number = t.ticket_number AND pay.payment_status = 'Success'
          GROUP BY c.company_id, c.company_name, c.model
          ORDER BY revenue DESC`
    );
    const [occupancy] = await pool.query(
        `SELECT flight_id, flight_name, source_city, destination, departure_time, status,
                capacity, seats_available,
                ROUND(100 * (capacity - seats_available) / NULLIF(capacity, 0), 1) AS occupancy_percent
           FROM v_flight_schedule
          ORDER BY occupancy_percent DESC, departure_time
          LIMIT 5`
    );
    ok(res, { summary: row, revenue_by_airline: revenueByAirline, top_occupancy: occupancy });
}));

app.get('/api/reports/revenue', asyncHandler(async (req, res) => {
    const [rows] = await pool.query(
        `SELECT c.company_id, c.company_name,
                COUNT(DISTINCT b.booking_id)  AS bookings,
                COALESCE(SUM(pay.amount), 0)  AS revenue
           FROM airplane_company c
           LEFT JOIN flight  f   ON f.company_id = c.company_id
           LEFT JOIN booking b   ON b.flight_id  = f.flight_id AND b.booking_status <> 'Cancelled'
           LEFT JOIN ticket  t   ON t.booking_id = b.booking_id
           LEFT JOIN payment pay ON pay.ticket_number = t.ticket_number AND pay.payment_status = 'Success'
          GROUP BY c.company_id, c.company_name
          ORDER BY revenue DESC`
    );
    ok(res, rows);
}));

/* ---------------------------------------------------------------------------
   5. FALLBACKS AND ERROR HANDLING
   --------------------------------------------------------------------------- */
app.use('/api', (req, res) => {
    res.status(404).json({ success: false, message: `Unknown API endpoint: ${req.method} /api${req.path}` });
});

app.use((err, req, res, _next) => {
    let status = err.status || 500;
    let message = err.message || 'Internal server error';
    let details = err.details;

    // Translate common MySQL errors into friendly HTTP responses
    switch (err.code) {
        case 'ER_DUP_ENTRY':
            status = 409;
            message = 'Duplicate entry - a record with this unique key already exists (e.g. the same seat on the same flight).';
            break;
        case 'ER_NO_REFERENCED_ROW_2':
            status = 400;
            message = 'Foreign key check failed: the referenced airport / company / flight / passenger does not exist.';
            break;
        case 'ER_ROW_IS_REFERENCED_2':
            status = 409;
            message = 'Cannot delete: other rows still reference this record (ON DELETE RESTRICT).';
            break;
        case 'ER_NO_SUCH_TABLE':
            status = 500;
            message = 'Table not found. Did you import the database? Run: mysql -u root -p -e "SOURCE database/schema.sql;"';
            break;
        case 'ECONNREFUSED':
        case 'ER_ACCESS_DENIED_ERROR':
            status = 503;
            message = 'Cannot reach MySQL. Check that the MySQL service is running and that the DB_USER / DB_PASSWORD in .env are correct.';
            break;
        default:
            break;
    }

    if (status >= 500) console.error('[ERROR]', err);
    res.status(status).json({ success: false, message, details, error_code: err.code || null, path: req.originalUrl });
});

/* ---------------------------------------------------------------------------
   6. STARTUP
   --------------------------------------------------------------------------- */
async function start() {
    try {
        const [[row]] = await pool.query('SELECT DATABASE() AS db, VERSION() AS version');
        console.log(`\n[DB] Connected to "${row.db}" (MySQL/MariaDB ${row.version})`);
    } catch (err) {
        console.error('\n============================================================');
        console.error('  DATABASE NOT REACHABLE - the API will fail until this is fixed');
        console.error(`  Reason: ${err.code || err.message}`);
        console.error('  Checklist:');
        console.error('    1) Is the MySQL service running?   (PowerShell: Get-Service MySQL80)');
        console.error('    2) Did you import the schema?      mysql -u root -p -e "SOURCE database/schema.sql;"');
        console.error('    3) Are DB_USER / DB_PASSWORD in the .env file correct?');
        console.error('============================================================\n');
    }

    app.listen(PORT, '0.0.0.0', () => {
        console.log('============================================================');
        console.log('  FLIGHT MANAGEMENT SYSTEM  -  server started');
        console.log(`  Dashboard : http://localhost:${PORT}`);
        console.log(`  Health    : http://localhost:${PORT}/api/health`);
        console.log(`  Flights   : http://localhost:${PORT}/api/flights`);
        console.log(`  DB        : ${process.env.DB_USER}@${process.env.DB_HOST}:${process.env.DB_PORT || 3306}/${process.env.DB_NAME}`);
        console.log('  Stop      : press Ctrl + C');
        console.log('============================================================\n');
    });
}

if (require.main === module) start();

module.exports = { app, pool, withTransaction };
