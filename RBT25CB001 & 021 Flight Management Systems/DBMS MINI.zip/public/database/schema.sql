/* ============================================================================
   FLIGHT MANAGEMENT SYSTEM (FMS)  --  MySQL 8.x / MariaDB 10.4+
   File   : database/schema.sql
   Author : <YOUR NAME>  |  Roll No: <YOUR ROLL NO>
   Course : B.Tech CSE & Business Systems  --  DBMS / Web Technology Project
   ----------------------------------------------------------------------------
   PURPOSE
   Creates the complete relational database derived from the project ER diagram
   (8 entities) and loads realistic sample data for demonstration.

   HOW TO RUN (PowerShell, from the project root folder)
       mysql -u root -p -e "SOURCE C:/full/path/database/schema.sql;"
     or
       cmd /c "mysql -u root -p < database\schema.sql"
     or use the helper script:  .\scripts\setup-db.ps1

   WARNING: This script DROPS the database `flight_management_system` if it
            already exists. All existing data in it will be lost.
   ============================================================================ */

DROP DATABASE IF EXISTS flight_management_system;

CREATE DATABASE flight_management_system
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE flight_management_system;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 1;

/* ============================================================================
   SECTION 1 : TABLE DEFINITIONS
   ----------------------------------------------------------------------------
   Legend for columns that are NOT in the original ER diagram:
       -- EXTENSION : column added for practical/UI reasons. Every extension is
                       documented in docs/03-er-diagram-summary.md so that it can
                       be explained clearly in the viva.
   ============================================================================ */

-- ---------------------------------------------------------------------------
-- 1. AIRPORT   (Parent entity: "operates flights")
-- ---------------------------------------------------------------------------
CREATE TABLE airport (
    airport_license VARCHAR(12)  NOT NULL,
    airport_name    VARCHAR(100) NOT NULL,
    type            ENUM('International','Domestic','Private','Cargo') NOT NULL DEFAULT 'Domestic',
    country         VARCHAR(60)  NOT NULL,
    state           VARCHAR(60)  NOT NULL,
    city            VARCHAR(60)  NOT NULL,
    PRIMARY KEY (airport_license),
    UNIQUE KEY uq_airport_name (airport_name),
    KEY idx_airport_city (city)
) ENGINE = InnoDB
  COMMENT = 'Airports that operate flights. Location is modelled as attributes country/state/city per ER diagram.';

-- ---------------------------------------------------------------------------
-- 2. AIRPLANE_COMPANY   (Uses airplanes, employs pilots, operates flights)
-- ---------------------------------------------------------------------------
CREATE TABLE airplane_company (
    company_id       VARCHAR(10)  NOT NULL,
    company_name     VARCHAR(80)  NOT NULL,          -- EXTENSION (display only)
    model            VARCHAR(60)  NOT NULL,
    type_of_airplane ENUM('Narrow-body','Wide-body','Regional','Cargo') NOT NULL,
    capacity         INT          NOT NULL,
    fuel_type        VARCHAR(60)  NOT NULL,
    engine_type      VARCHAR(60)  NOT NULL,
    PRIMARY KEY (company_id),
    CONSTRAINT chk_company_capacity CHECK (capacity BETWEEN 1 AND 900)
) ENGINE = InnoDB
  COMMENT = 'Airline companies / operators and the aircraft type they fly.';

-- ---------------------------------------------------------------------------
-- 3. PILOT   (Employed by a company)
--    Relationship: AIRPLANE_COMPANY 1 ---- N PILOT  (company_id FK)
--    ON DELETE SET NULL  -> if a company row is removed, its pilots are kept
--    but marked as unassigned (safer than deleting people records).
-- ---------------------------------------------------------------------------
CREATE TABLE pilot (
    pilot_license  VARCHAR(20) NOT NULL,
    pilot_name     VARCHAR(80) NOT NULL,              -- EXTENSION (display only)
    contact_number VARCHAR(25) NOT NULL,
    role           ENUM('Captain','Senior First Officer','First Officer',
                        'Flight Engineer','Cadet Pilot','Instructor') NOT NULL,
    age            INT         NOT NULL,
    date_of_birth  DATE        NOT NULL,
    experience     INT         NOT NULL COMMENT 'Flying experience in years',
    company_id     VARCHAR(10) NULL,
    PRIMARY KEY (pilot_license),
    KEY idx_pilot_company (company_id),
    CONSTRAINT fk_pilot_company
        FOREIGN KEY (company_id) REFERENCES airplane_company (company_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE,
    CONSTRAINT chk_pilot_age CHECK (age BETWEEN 18 AND 70),
    CONSTRAINT chk_pilot_experience CHECK (experience >= 0)
) ENGINE = InnoDB
  COMMENT = 'Pilots employed by an airline company.';

-- ---------------------------------------------------------------------------
-- 4. FLIGHT   (Operated by one airport + one company)
--    FLIGHT N ---- 1 AIRPORT   (airport_license FK)  -> RESTRICT
--    FLIGHT N ---- 1 COMPANY   (company_id FK)       -> RESTRICT
--    RESTRICT protects operational history: you cannot delete an airport or a
--    company while flights still reference it.
-- ---------------------------------------------------------------------------
CREATE TABLE flight (
    flight_id        VARCHAR(12)  NOT NULL,
    flight_name      VARCHAR(60)  NOT NULL,
    departure_time   DATETIME     NOT NULL,
    duration_minutes INT          NOT NULL COMMENT 'Duration in minutes (arrival is derived)',
    status           ENUM('Scheduled','Delayed','Departed','Arrived','Cancelled') NOT NULL DEFAULT 'Scheduled',
    destination      VARCHAR(60)  NOT NULL COMMENT 'Destination city/airport name',
    fare             DECIMAL(10,2) NOT NULL DEFAULT 0.00,  -- EXTENSION (needed for payment amount)
    airport_license  VARCHAR(12)  NOT NULL COMMENT 'Origin/source airport',
    company_id       VARCHAR(10)  NOT NULL,
    PRIMARY KEY (flight_id),
    KEY idx_flight_departure (departure_time),
    KEY idx_flight_route (airport_license, destination),
    KEY idx_flight_company (company_id),
    KEY idx_flight_status (status),
    CONSTRAINT fk_flight_airport
        FOREIGN KEY (airport_license) REFERENCES airport (airport_license)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT fk_flight_company
        FOREIGN KEY (company_id) REFERENCES airplane_company (company_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT chk_flight_duration CHECK (duration_minutes BETWEEN 20 AND 1200),
    CONSTRAINT chk_flight_fare CHECK (fare >= 0)
) ENGINE = InnoDB
  COMMENT = 'Flights. departure_time + duration_minutes gives the arrival time.';

-- ---------------------------------------------------------------------------
-- 5. PASSENGER
-- ---------------------------------------------------------------------------
CREATE TABLE passenger (
    passenger_id   INT          NOT NULL AUTO_INCREMENT,
    passenger_name VARCHAR(80)  NOT NULL,
    email          VARCHAR(120) NOT NULL,
    phone_number   VARCHAR(25)  NOT NULL,
    PRIMARY KEY (passenger_id),
    UNIQUE KEY uq_passenger_email (email)
) ENGINE = InnoDB
  COMMENT = 'Passengers who make bookings.';

-- ---------------------------------------------------------------------------
-- 6. BOOKING   (Passenger N ---- 1 FLIGHT, Passenger 1 ---- N BOOKING)
--    BOOKING N ---- 1 PASSENGER  -> ON DELETE CASCADE (delete passenger =>
--                                   their bookings/PNR history is removed)
--    BOOKING N ---- 1 FLIGHT     -> ON DELETE CASCADE (delete flight =>
--                                   its bookings are removed)
-- ---------------------------------------------------------------------------
CREATE TABLE booking (
    booking_id     INT          NOT NULL AUTO_INCREMENT,
    seat_number    VARCHAR(5)   NOT NULL,
    booking_status ENUM('Pending','Confirmed','Checked-in','Cancelled') NOT NULL DEFAULT 'Pending',
    booking_date   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    passenger_id   INT          NOT NULL,
    flight_id      VARCHAR(12)  NOT NULL,
    /* Generated (virtual copy) column + unique key: this is what makes it
       IMPOSSIBLE to double-book the same seat on the same flight from two
       simultaneous requests. Cancelled bookings hold NULL, and MySQL allows
       many NULLs inside a UNIQUE index, so cancelled seats become bookable
       again automatically. */
    seat_hold      VARCHAR(5) GENERATED ALWAYS AS
                   (IF(booking_status = 'Cancelled', NULL, seat_number)) STORED,
    PRIMARY KEY (booking_id),
    UNIQUE KEY uq_booking_active_seat (flight_id, seat_hold),
    KEY idx_booking_passenger (passenger_id),
    KEY idx_booking_flight (flight_id),
    KEY idx_booking_status (booking_status),
    CONSTRAINT fk_booking_passenger
        FOREIGN KEY (passenger_id) REFERENCES passenger (passenger_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_booking_flight
        FOREIGN KEY (flight_id) REFERENCES flight (flight_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE = InnoDB
  COMMENT = 'Booking/PNR record linking one passenger to one seat on one flight.';

-- ---------------------------------------------------------------------------
-- 7. TICKET   (One booking generates one ticket)
--    Relationship: BOOKING 1 ---- 1 TICKET
-- ---------------------------------------------------------------------------
CREATE TABLE ticket (
    ticket_number VARCHAR(20) NOT NULL,
    boarding_time DATETIME    NOT NULL,
    terminal      VARCHAR(8)  NOT NULL COMMENT 'e.g. T1, T2, T3',
    seat_number   VARCHAR(5)  NOT NULL,
    booking_id    INT         NOT NULL,
    PRIMARY KEY (ticket_number),
    UNIQUE KEY uq_ticket_booking (booking_id) COMMENT '1:1 with booking',
    KEY idx_ticket_booking (booking_id),
    CONSTRAINT fk_ticket_booking
        FOREIGN KEY (booking_id) REFERENCES booking (booking_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE = InnoDB
  COMMENT = 'Boarding ticket generated for a booking (1:1).';

-- ---------------------------------------------------------------------------
-- 8. PAYMENT   (A ticket is paid for by one payment)
--    Relationship: TICKET 1 ---- 1 PAYMENT
-- ---------------------------------------------------------------------------
CREATE TABLE payment (
    transaction_id VARCHAR(24)  NOT NULL,
    payment_type   ENUM('UPI','Credit Card','Debit Card','Net Banking','Wallet','Cash') NOT NULL,
    payment_date   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    amount         DECIMAL(10,2) NOT NULL DEFAULT 0.00, -- EXTENSION (money trail)
    payment_status ENUM('Pending','Success','Failed','Refunded') NOT NULL DEFAULT 'Pending', -- EXTENSION
    ticket_number  VARCHAR(20)  NOT NULL,
    PRIMARY KEY (transaction_id),
    UNIQUE KEY uq_payment_ticket (ticket_number) COMMENT '1:1 with ticket',
    KEY idx_payment_ticket (ticket_number),
    CONSTRAINT fk_payment_ticket
        FOREIGN KEY (ticket_number) REFERENCES ticket (ticket_number)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT chk_payment_amount CHECK (amount >= 0)
) ENGINE = InnoDB
  COMMENT = 'Payment made against a ticket (1:1).';

/* ============================================================================
   SECTION 2 : SAMPLE DATA
   Dates are written relative to CURDATE() / NOW() so the dashboard ALWAYS
   shows today's and upcoming flights, no matter when the project is demoed.
   ============================================================================ */

-- --------------------------- 2.1 AIRPORTS (9) ------------------------------
INSERT INTO airport (airport_license, airport_name, type, country, state, city) VALUES
('IN-DEL-01', 'Indira Gandhi International Airport',        'International', 'India',        'Delhi',        'New Delhi'),
('IN-BOM-01', 'Chhatrapati Shivaji Maharaj Intl Airport',   'International', 'India',        'Maharashtra',  'Mumbai'),
('IN-PNQ-01', 'Pune International Airport',                 'Domestic',      'India',        'Maharashtra',  'Pune'),
('IN-BLR-01', 'Kempegowda International Airport',           'International', 'India',        'Karnataka',    'Bengaluru'),
('IN-MAA-01', 'Chennai International Airport',              'International', 'India',        'Tamil Nadu',   'Chennai'),
('IN-HYD-01', 'Rajiv Gandhi International Airport',         'Domestic',      'India',        'Telangana',    'Hyderabad'),
('AE-DXB-01', 'Dubai International Airport',                'International', 'UAE',          'Dubai',        'Dubai'),
('SG-SIN-01', 'Singapore Changi Airport',                   'International', 'Singapore',    'Singapore',    'Singapore'),
('GB-LHR-01', 'London Heathrow Airport',                    'International', 'United Kingdom','England',      'London');

-- ---------------------- 2.2 AIRPLANE COMPANIES (5) -------------------------
INSERT INTO airplane_company
    (company_id, company_name, model, type_of_airplane, capacity, fuel_type, engine_type) VALUES
('IND-6E', 'IndiGo',             'Airbus A320neo',   'Narrow-body', 186, 'Aviation Turbine Fuel (Jet A-1)', 'CFM LEAP-1A'),
('AIC-AI', 'Air India',          'Boeing 787-8',     'Wide-body',   256, 'Aviation Turbine Fuel (Jet A-1)', 'General Electric GEnx-1B67'),
('VTI-UK', 'Vistara',            'Airbus A321neo',   'Narrow-body', 232, 'Aviation Turbine Fuel (Jet A-1)', 'CFM LEAP-1A'),
('UAE-EK', 'Emirates',           'Boeing 777-300ER', 'Wide-body',   354, 'Aviation Turbine Fuel (Jet A-1)', 'General Electric GE90-115B'),
('SIA-SQ', 'Singapore Airlines', 'Airbus A380-800',  'Wide-body',   471, 'Sustainable Aviation Fuel (SAF)', 'Rolls-Royce Trent 970');

-- ------------------- 2.3 PILOTS (13 = 12 employed + 1 freelancer) -------------------
INSERT INTO pilot (pilot_license, pilot_name, contact_number, role, age, date_of_birth, experience, company_id) VALUES
('PL-IND-1001', 'Capt. Arjun Mehta',              '+91-98200-11001', 'Captain',              44, '1982-03-15', 18, 'IND-6E'),
('PL-IND-1002', 'Capt. Neha Kulkarni',            '+91-98200-11002', 'Captain',              39, '1987-07-22', 13, 'IND-6E'),
('PL-IND-1003', 'F/O Rohan Deshpande',            '+91-98200-11003', 'First Officer',        31, '1995-01-09',  6, 'IND-6E'),
('PL-AIC-2001', 'Capt. Vikram Rao',               '+91-98110-22001', 'Captain',              51, '1975-11-02', 24, 'AIC-AI'),
('PL-AIC-2002', 'F/O Sneha Iyer',                 '+91-98110-22002', 'First Officer',        33, '1993-05-30',  8, 'AIC-AI'),
('PL-AIC-2003', 'SFO Imran Qureshi',              '+91-98110-22003', 'Senior First Officer', 37, '1989-06-11', 12, 'AIC-AI'),
('PL-VTI-3001', 'Capt. Karan Malhotra',           '+91-98700-33001', 'Captain',              42, '1984-09-12', 16, 'VTI-UK'),
('PL-VTI-3002', 'F/O Aditi Sharma',               '+91-98700-33002', 'First Officer',        29, '1997-02-18',  5, 'VTI-UK'),
('PL-EK-4001',  'Capt. Omar Al Farsi',            '+971-50-700-4001','Captain',              47, '1979-04-25', 21, 'UAE-EK'),
('PL-EK-4002',  'F/O Priya Nair',                 '+971-50-700-4002','First Officer',        34, '1992-08-08',  9, 'UAE-EK'),
('PL-SQ-5001',  'Capt. Wei Ming Tan',             '+65-9123-5001',   'Captain',              45, '1981-06-14', 19, 'SIA-SQ'),
('PL-SQ-5002',  'Cadet Pilot Ananya Bose',        '+65-9123-5002',   'Cadet Pilot',          24, '2002-04-20',  1, 'SIA-SQ');
-- A freelancer with no company (shows that a nullable FK is valid):
INSERT INTO pilot (pilot_license, pilot_name, contact_number, role, age, date_of_birth, experience, company_id) VALUES
('PL-FRE-9001', 'Capt. Devendra Salunkhe (Contract)', '+91-90210-90010', 'Instructor', 56, '1969-10-05', 30, NULL);

-- ----------------------------- 2.4 FLIGHTS (21) ----------------------------
-- Today's operations
INSERT INTO flight (flight_id, flight_name, departure_time, duration_minutes, status, destination, fare, airport_license, company_id) VALUES
('6E-1301', 'IndiGo 6E-1301',  TIMESTAMP(CURDATE(), '05:30:00'),                      130, 'Arrived',   'New Delhi', 5299.00, 'IN-PNQ-01', 'IND-6E'),
('UK-973',  'Vistara UK-973',  TIMESTAMP(CURDATE(), '07:45:00'),                      140, 'Departed',  'New Delhi', 6199.00, 'IN-BOM-01', 'VTI-UK'),
('6E-1502', 'IndiGo 6E-1502',  TIMESTAMP(CURDATE(), '20:15:00'),                      125, 'Scheduled', 'Pune',      5399.00, 'IN-DEL-01', 'IND-6E'),
('AI-805',  'Air India AI-805',TIMESTAMP(CURDATE(), '22:40:00'),                      165, 'Scheduled', 'Chennai',   6699.00, 'IN-DEL-01', 'AIC-AI'),
-- Yesterday (history, useful for reports)
('6E-1201', 'IndiGo 6E-1201',  TIMESTAMP(CURDATE() - INTERVAL 1 DAY, '06:00:00'),     105, 'Arrived',   'Bengaluru', 4299.00, 'IN-PNQ-01', 'IND-6E'),
-- Tomorrow
('6E-2043', 'IndiGo 6E-2043',  TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '06:15:00'),     130, 'Scheduled', 'New Delhi', 5499.00, 'IN-PNQ-01', 'IND-6E'),
('6E-2047', 'IndiGo 6E-2047',  TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '09:40:00'),     105, 'Scheduled', 'Bengaluru', 4399.00, 'IN-PNQ-01', 'IND-6E'),
('UK-995',  'Vistara UK-995',  TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '08:00:00'),     140, 'Delayed',   'New Delhi', 6299.00, 'IN-BOM-01', 'VTI-UK'),
('AI-806',  'Air India AI-806',TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '11:25:00'),     165, 'Scheduled', 'Chennai',   6899.00, 'IN-DEL-01', 'AIC-AI'),
('6E-5301', 'IndiGo 6E-5301',  TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '14:10:00'),      95, 'Scheduled', 'Hyderabad', 3999.00, 'IN-BOM-01', 'IND-6E'),
('UK-869',  'Vistara UK-869',  TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '17:55:00'),     115, 'Scheduled', 'Mumbai',    5199.00, 'IN-BLR-01', 'VTI-UK'),
-- Day after tomorrow (international)
('AI-101',  'Air India AI-101',TIMESTAMP(CURDATE() + INTERVAL 2 DAY, '02:30:00'),     570, 'Scheduled', 'London',   42999.00, 'IN-DEL-01', 'AIC-AI'),
('EK-507',  'Emirates EK-507', TIMESTAMP(CURDATE() + INTERVAL 2 DAY, '04:05:00'),     195, 'Scheduled', 'Dubai',    18499.00, 'IN-BOM-01', 'UAE-EK'),
('SQ-511',  'Singapore SQ-511',TIMESTAMP(CURDATE() + INTERVAL 2 DAY, '23:45:00'),     275, 'Scheduled', 'Singapore',21999.00, 'IN-BLR-01', 'SIA-SQ'),
('6E-6112', 'IndiGo 6E-6112',  TIMESTAMP(CURDATE() + INTERVAL 2 DAY, '07:20:00'),     125, 'Scheduled', 'Pune',      5199.00, 'IN-DEL-01', 'IND-6E'),
('UK-871',  'Vistara UK-871',  TIMESTAMP(CURDATE() + INTERVAL 2 DAY, '12:35:00'),      65, 'Scheduled', 'Bengaluru', 3199.00, 'IN-MAA-01', 'VTI-UK'),
-- Day 3
('EK-508',  'Emirates EK-508', TIMESTAMP(CURDATE() + INTERVAL 3 DAY, '06:50:00'),     185, 'Scheduled', 'Mumbai',   17499.00, 'AE-DXB-01', 'UAE-EK'),
('AI-102',  'Air India AI-102',TIMESTAMP(CURDATE() + INTERVAL 3 DAY, '13:15:00'),     545, 'Scheduled', 'New Delhi',44999.00, 'GB-LHR-01', 'AIC-AI'),
('SQ-512',  'Singapore SQ-512',TIMESTAMP(CURDATE() + INTERVAL 3 DAY, '20:10:00'),     260, 'Scheduled', 'Bengaluru',20999.00, 'SG-SIN-01', 'SIA-SQ'),
('6E-2189', 'IndiGo 6E-2189',  TIMESTAMP(CURDATE() + INTERVAL 3 DAY, '16:40:00'),      90, 'Scheduled', 'Pune',      3799.00, 'IN-HYD-01', 'IND-6E'),
('AI-441',  'Air India AI-441',TIMESTAMP(CURDATE() + INTERVAL 3 DAY, '19:05:00'),     145, 'Scheduled', 'Mumbai',    5899.00, 'IN-DEL-01', 'AIC-AI');

-- ---------------------------- 2.5 PASSENGERS (10) --------------------------
INSERT INTO passenger (passenger_name, email, phone_number) VALUES
('Aarav Sharma',  'aarav.sharma@example.com',  '+91-98765-43210'),
('Diya Patel',    'diya.patel@example.com',    '+91-91234-56780'),
('Kabir Singh',   'kabir.singh@example.com',   '+91-99887-76655'),
('Meera Joshi',   'meera.joshi@example.com',   '+91-90045-12345'),
('Rohan Verma',   'rohan.verma@example.com',   '+91-98111-22334'),
('Ananya Reddy',  'ananya.reddy@example.com',  '+91-97000-55667'),
('Ishaan Gupta',  'ishaan.gupta@example.com',  '+91-96543-21098'),
('Saanvi Desai',  'saanvi.desai@example.com',  '+91-90909-80808'),
('Vihaan Nair',   'vihaan.nair@example.com',   '+91-94444-33322'),
('Zoya Khan',     'zoya.khan@example.com',     '+91-93222-11009');


-- ----------------------------- 2.6 BOOKINGS (12) ---------------------------
INSERT INTO booking (seat_number, booking_status, booking_date, passenger_id, flight_id) VALUES
('12A', 'Confirmed',  DATE_SUB(NOW(), INTERVAL 3 DAY), 1,  '6E-2043'),
('12B', 'Confirmed',  DATE_SUB(NOW(), INTERVAL 3 DAY), 2,  '6E-2043'),
('14C', 'Confirmed',  DATE_SUB(NOW(), INTERVAL 2 DAY), 3,  '6E-2043'),
('09A', 'Confirmed',  DATE_SUB(NOW(), INTERVAL 2 DAY), 4,  '6E-2047'),
('21F', 'Confirmed',  DATE_SUB(NOW(), INTERVAL 5 DAY), 5,  'UK-995'),
('18D', 'Confirmed',  DATE_SUB(NOW(), INTERVAL 4 DAY), 6,  'AI-806'),
('05B', 'Cancelled',  DATE_SUB(NOW(), INTERVAL 6 DAY), 7,  '6E-5301'),
('27A', 'Confirmed',  DATE_SUB(NOW(), INTERVAL 10 DAY),8,  'AI-101'),
('33C', 'Confirmed',  DATE_SUB(NOW(), INTERVAL 8 DAY), 9,  'EK-507'),
('41F', 'Confirmed',  DATE_SUB(NOW(), INTERVAL 8 DAY), 10, 'SQ-511'),
('17E', 'Confirmed',  DATE_SUB(NOW(), INTERVAL 1 DAY), 1,  '6E-1502'),
('22B', 'Pending',    DATE_SUB(NOW(), INTERVAL 4 HOUR),2,  'AI-805');


-- NOTE: booking 12 is intentionally left "Pending" with NO ticket/payment row.
--       It is used in the dashboard to demonstrate LEFT JOIN + NULL handling.

-- ----------------------------- 2.7 TICKETS (11) ----------------------------
-- boarding_time = departure_time - 45 minutes
INSERT INTO ticket (ticket_number, boarding_time, terminal, seat_number, booking_id) VALUES
(CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0001'), TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '05:30:00'), 'T1', '12A', 1),
(CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0002'), TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '05:30:00'), 'T1', '12B', 2),
(CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0003'), TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '05:30:00'), 'T1', '14C', 3),
(CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0004'), TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '08:55:00'), 'T1', '09A', 4),
(CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0005'), TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '07:15:00'), 'T2', '21F', 5),
(CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0006'), TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '10:40:00'), 'T3', '18D', 6),
(CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0007'), TIMESTAMP(CURDATE() + INTERVAL 1 DAY, '13:25:00'), 'T1', '05B', 7),
(CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 2 DAY, '%Y%m%d'), '-0008'), TIMESTAMP(CURDATE() + INTERVAL 2 DAY, '01:45:00'), 'T3', '27A', 8),
(CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 2 DAY, '%Y%m%d'), '-0009'), TIMESTAMP(CURDATE() + INTERVAL 2 DAY, '03:20:00'), 'T2', '33C', 9),
(CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 2 DAY, '%Y%m%d'), '-0010'), TIMESTAMP(CURDATE() + INTERVAL 2 DAY, '23:00:00'), 'T1', '41F', 10),
(CONCAT('TKT-', DATE_FORMAT(CURDATE(), '%Y%m%d'), '-0011'),                 TIMESTAMP(CURDATE(), '19:30:00'),                     'T1', '17E', 11);

-- ---------------------------- 2.8 PAYMENTS (11) ----------------------------
-- Amount equals the fare of the corresponding flight. Booking 7 was cancelled
-- => its payment is marked 'Refunded' (a real-world audit trail).
INSERT INTO payment (transaction_id, payment_type, payment_date, amount, payment_status, ticket_number) VALUES
(CONCAT('TXN-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0001'), 'UPI',          DATE_SUB(NOW(), INTERVAL 3 DAY), 5499.00, 'Success',  CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0001')),
(CONCAT('TXN-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0002'), 'Credit Card',  DATE_SUB(NOW(), INTERVAL 3 DAY), 5499.00, 'Success',  CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0002')),
(CONCAT('TXN-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0003'), 'Debit Card',   DATE_SUB(NOW(), INTERVAL 2 DAY), 5499.00, 'Success',  CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0003')),
(CONCAT('TXN-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0004'), 'Net Banking',  DATE_SUB(NOW(), INTERVAL 2 DAY), 4399.00, 'Success',  CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0004')),
(CONCAT('TXN-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0005'), 'Wallet',       DATE_SUB(NOW(), INTERVAL 5 DAY), 6299.00, 'Success',  CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0005')),
(CONCAT('TXN-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0006'), 'UPI',          DATE_SUB(NOW(), INTERVAL 4 DAY), 6899.00, 'Success',  CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0006')),
(CONCAT('TXN-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0007'), 'Credit Card',  DATE_SUB(NOW(), INTERVAL 6 DAY), 3999.00, 'Refunded', CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 1 DAY, '%Y%m%d'), '-0007')),
(CONCAT('TXN-', DATE_FORMAT(CURDATE() + INTERVAL 2 DAY, '%Y%m%d'), '-0008'), 'Credit Card',  DATE_SUB(NOW(), INTERVAL 10 DAY),42999.00,'Success',  CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 2 DAY, '%Y%m%d'), '-0008')),
(CONCAT('TXN-', DATE_FORMAT(CURDATE() + INTERVAL 2 DAY, '%Y%m%d'), '-0009'), 'UPI',          DATE_SUB(NOW(), INTERVAL 8 DAY), 18499.00, 'Success',  CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 2 DAY, '%Y%m%d'), '-0009')),
(CONCAT('TXN-', DATE_FORMAT(CURDATE() + INTERVAL 2 DAY, '%Y%m%d'), '-0010'), 'Net Banking',  DATE_SUB(NOW(), INTERVAL 8 DAY), 21999.00, 'Success',  CONCAT('TKT-', DATE_FORMAT(CURDATE() + INTERVAL 2 DAY, '%Y%m%d'), '-0010')),
(CONCAT('TXN-', DATE_FORMAT(CURDATE(), '%Y%m%d'), '-0011'),                 'UPI',          DATE_SUB(NOW(), INTERVAL 1 DAY), 5399.00, 'Success',  CONCAT('TKT-', DATE_FORMAT(CURDATE(), '%Y%m%d'), '-0011'));

/* ============================================================================
   SECTION 3 : VIEWS  (pre-written JOINs -> used by the dashboard APIs)
   ============================================================================ */

-- Flight schedule with source airport, airline, computed arrival time and
-- live seat availability (capacity - active bookings).
CREATE OR REPLACE VIEW v_flight_schedule AS
SELECT  f.flight_id,
        f.flight_name,
        a.airport_license,
        a.airport_name                       AS source_airport,
        a.city                               AS source_city,
        f.destination,
        f.departure_time,
        DATE_FORMAT(f.departure_time, '%H:%i') AS departure_hm,
        f.duration_minutes,
        DATE_ADD(f.departure_time, INTERVAL f.duration_minutes MINUTE) AS arrival_time,
        f.status,
        f.fare,
        c.company_id,
        c.company_name,
        c.model,
        c.type_of_airplane,
        c.capacity,
        c.capacity - COALESCE((SELECT COUNT(*)
                                 FROM booking b
                                WHERE b.flight_id      = f.flight_id
                                  AND b.booking_status <> 'Cancelled'), 0) AS seats_available
FROM    flight f
        JOIN airport a          ON a.airport_license = f.airport_license
        JOIN airplane_company c ON c.company_id      = f.company_id;

-- Full reservation view: passenger + flight + ticket + payment in one row.
-- LEFT JOINs are intentional: a Pending booking has no ticket/payment yet.
CREATE OR REPLACE VIEW v_reservation_details AS
SELECT  b.booking_id,
        b.booking_status,
        b.booking_date,
        b.seat_number,
        p.passenger_id,
        p.passenger_name,
        p.email,
        p.phone_number,
        f.flight_id,
        f.flight_name,
        f.departure_time,
        f.destination,
        f.status                        AS flight_status,
        a.city                          AS source_city,
        t.ticket_number,
        t.boarding_time,
        t.terminal,
        pay.transaction_id,
        pay.payment_type,
        pay.payment_date,
        pay.amount,
        pay.payment_status
FROM    booking b
        JOIN passenger p        ON p.passenger_id   = b.passenger_id
        JOIN flight f           ON f.flight_id      = b.flight_id
        JOIN airport a          ON a.airport_license= f.airport_license
        LEFT JOIN ticket t      ON t.booking_id     = b.booking_id
        LEFT JOIN payment pay   ON pay.ticket_number= t.ticket_number;

-- Pilot roster with company details.
CREATE OR REPLACE VIEW v_pilot_roster AS
SELECT  pl.pilot_license, pl.pilot_name, pl.role, pl.age, pl.experience,
        pl.contact_number, pl.company_id, c.company_name, c.model
FROM    pilot pl
        LEFT JOIN airplane_company c ON c.company_id = pl.company_id;

/* ============================================================================
   SECTION 4 : VERIFICATION QUERIES  (run these to prove the schema is loaded)
   ============================================================================ */

-- 4.1 Row counts per table
SELECT 'airport' AS table_name, COUNT(*) AS rows_loaded FROM airport
UNION ALL SELECT 'airplane_company', COUNT(*) FROM airplane_company
UNION ALL SELECT 'pilot',            COUNT(*) FROM pilot
UNION ALL SELECT 'flight',           COUNT(*) FROM flight
UNION ALL SELECT 'passenger',        COUNT(*) FROM passenger
UNION ALL SELECT 'booking',          COUNT(*) FROM booking
UNION ALL SELECT 'ticket',           COUNT(*) FROM ticket
UNION ALL SELECT 'payment',          COUNT(*) FROM payment;

-- 4.2 This is the query the dashboard's main table is based on
SELECT flight_id, flight_name, source_city, destination, departure_hm,
       duration_minutes, status, seats_available, fare
FROM   v_flight_schedule
ORDER  BY departure_time;

-- 4.3 Complete reservation report (5-table JOIN)
SELECT booking_id, passenger_name, flight_id, seat_number, booking_status,
       ticket_number, terminal, payment_type, amount, payment_status
FROM   v_reservation_details
ORDER  BY booking_date DESC;

-- 4.4 Revenue collected per airline (GROUP BY demo)
SELECT c.company_name,
       COUNT(DISTINCT b.booking_id)  AS bookings,
       COALESCE(SUM(pay.amount), 0)  AS revenue
FROM   airplane_company c
       LEFT JOIN flight  f   ON f.company_id = c.company_id
       LEFT JOIN booking b   ON b.flight_id  = f.flight_id AND b.booking_status <> 'Cancelled'
       LEFT JOIN ticket  t   ON t.booking_id = b.booking_id
       LEFT JOIN payment pay ON pay.ticket_number = t.ticket_number AND pay.payment_status = 'Success'
GROUP  BY c.company_id, c.company_name
ORDER  BY revenue DESC;

/* ============================================================================
   SECTION 5 : TRANSACTION DEMO (for the viva - run these two lines together)
   ----------------------------------------------------------------------------
   Shows ACID in action: the seat is held by an active booking, and the
   generated-column UNIQUE index refuses a duplicate.
   ============================================================================ */
-- START TRANSACTION;
-- INSERT INTO booking (seat_number, booking_status, passenger_id, flight_id)
-- VALUES ('12A', 'Confirmed', 5, '6E-2043');   -- ERROR 1062: Duplicate entry for key 'uq_booking_active_seat'
-- ROLLBACK;
-- Proof that a CANCELLED booking frees the seat:
-- UPDATE booking SET booking_status = 'Cancelled' WHERE booking_id = 1;
-- INSERT INTO booking (seat_number, booking_status, passenger_id, flight_id)
-- VALUES ('12A', 'Confirmed', 5, '6E-2043');   -- now succeeds

-- ===========================  END OF SCHEMA  ================================
