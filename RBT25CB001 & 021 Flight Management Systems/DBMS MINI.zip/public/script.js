/* ============================================================================
   SkyLedger Airlines - Flight Management System
   File : public/script.js        Theme : Air India Express inspired
   ----------------------------------------------------------------------------
   Vanilla JavaScript (ES2020) - no frameworks, no build step.

   API CONTRACT (served by server.js)
     GET    /api/health                    server + database status
     GET    /api/airports                  airports for the dropdowns
     GET    /api/flights?source=&destination=&date=&status=&q=&limit=
     GET    /api/flights/:id/seats         capacity, seats available, booked seats
     POST   /api/bookings                  ACID: booking -> ticket -> payment
     GET    /api/bookings?email=&passengerId=&flightId=&status=
     GET    /api/bookings/:id              one reservation
     PATCH  /api/bookings/:id/cancel       cancel + refund + release the seat
     GET    /api/stats/dashboard           counters, revenue per airline, occupancy

   SECTIONS
     1  helpers            api(), formatting, badges, toasts, alerts
     2  state + boot       health, airports, stats, deals, chat, nav
     3  flights            search card, quick filters, sort, table rendering
     4  booking            modal, seat map, submit, boarding pass, clean reset
     5  manage booking     lookup, list, cancel
     6  reports            revenue, occupancy, database summary
   ============================================================================ */

'use strict';

/* ==========================================================================
   §1  HELPERS
   ========================================================================== */

/** Thin fetch wrapper: always JSON, throws a readable Error on failure. */
async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined
  });

  let payload;
  try {
    payload = await response.json();
  } catch {
    throw new Error(`Server returned a non-JSON response (HTTP ${response.status}). Is server.js running?`);
  }

  if (!response.ok || payload.success === false) {
    const error = new Error(payload.message || `Request failed (HTTP ${response.status})`);
    error.status = response.status;
    error.details = payload.details;
    throw error;
  }
  return payload;                        // full { success, message, data } envelope
}

const $ = (id) => document.getElementById(id);

/** 5499 -> "₹5,499" */
const money = (value) =>
  '\u20B9' + Number(value || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });

/** '2026-10-15 06:15:00' -> '15 Oct 2026, 06:15 am' */
function prettyDateTime(value) {
  if (!value) return '\u2014';
  const date = new Date(String(value).replace(' ', 'T'));
  if (isNaN(date)) return value;
  return date.toLocaleString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: true
  });
}
const prettyDate = (value) => prettyDateTime(value).split(',')[0];

function prettyTime(value) {
  if (!value) return '\u2014';
  const date = new Date(String(value).replace(' ', 'T'));
  return isNaN(date)
    ? value
    : date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
}

/** 'YYYY-MM-DD' for today + offset days (used by the quick filters). */
function isoDate(offsetDays = 0) {
  const date = new Date();
  date.setDate(date.getDate() + offsetDays);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

/** Escapes text before it goes into innerHTML (XSS safety). */
const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[char]));

const badge = (value) => `<span class="badge badge-${esc(value)}">${esc(value)}</span>`;
const loadingRow = (tbody, colspan, text) =>
  { tbody.innerHTML = `<tr><td colspan="${colspan}" class="empty">${esc(text)}</td></tr>`; };

function toast(message, type = 'info', timeout = 4500) {
  const node = document.createElement('div');
  node.className = `toast ${type}`;
  node.innerHTML = `<p>${esc(message)}</p>`;
  $('toastStack').appendChild(node);
  setTimeout(() => node.remove(), timeout);
}

/** Inline alert box (used inside the booking modal). */
function renderAlert(container, type, title, detail = '') {
  container.innerHTML = `
    <div class="alert alert-${type}">
      <span class="alert-icon">${type === 'error' ? '\u26A0\uFE0F' : type === 'success' ? '\u2705' : '\u2139\uFE0F'}</span>
      <div><strong>${esc(title)}</strong>${detail ? `<span>${esc(detail)}</span>` : ''}</div>
    </div>`;
}

/* ==========================================================================
   §2  STATE + BOOT
   ========================================================================== */

const state = {
  airports: [],          // /api/airports rows
  flights: [],           // last result set from /api/flights (already filtered)
  quick: null,           // active quick filter: today | tomorrow | scheduled | cheap | intl
  sort: 'departure',
  maxFare: 6000,         // used by the "Under ₹6,000" quick filter
  intlCities: ['Dubai', 'Singapore', 'London']
};

/* Boot guard: if this file is ever included twice, or the event fires twice,
   the listeners and the initial API calls still only run once. */
let booted = false;

document.addEventListener('DOMContentLoaded', async () => {
  if (booted) return;
  booted = true;

  wireSearchCard();
  wireSearchTabs();
  wireHeaderActions();
  wireChat();
  wireBookingModal();
  wireManageBooking();
  wireReports();

  await Promise.all([
    checkHealth(),
    loadAirports(),
    loadStats(),
    loadFlights(),
    loadReports(),
    loadBookings()
  ]);
  renderDeals();          // needs the flight list, so it runs after loadFlights()
});

/** GET /api/health -> status line in the footer. */
async function checkHealth() {
  const line = $('dbStatus');
  try {
    const { data } = await api('/api/health');
    line.className = 'status-inline status-ok';
    line.innerHTML = `<span class="dot"></span> Database connected &middot; ${esc(data.db_name)}`;
  } catch (error) {
    line.className = 'status-inline status-bad';
    line.innerHTML = '<span class="dot"></span> Database offline';
    toast('Cannot reach the API: ' + error.message, 'error', 8000);
  }
}

/** Fills the "Flying from" dropdown from /api/airports. */
async function loadAirports() {
  try {
    const { data } = await api('/api/airports');
    state.airports = data;
    $('searchFrom').innerHTML =
      '<option value="">Any airport</option>' +
      data.map((airport) =>
        `<option value="${esc(airport.airport_license)}">${esc(airport.city)} (${esc(airport.airport_license)}) &mdash; ${esc(airport.airport_name)}</option>`
      ).join('');
  } catch (error) {
    console.warn('Could not load airports:', error.message);
  }
}

/* ==========================================================================
   §3  SEARCH CARD + FLIGHTS TABLE
   ========================================================================== */

function wireSearchCard() {
  $('searchForm').addEventListener('submit', (event) => {
    event.preventDefault();
    clearQuickFilter();
    loadFlights();
  });

  $('searchReset').addEventListener('click', () => {
    $('searchForm').reset();
    clearQuickFilter();
    loadFlights();
  });

  $('btnViewAll').addEventListener('click', () => {
    $('searchForm').reset();
    clearQuickFilter();
    loadFlights();
    $('flights').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

  $('btnPromoBook').addEventListener('click', () => scrollToId('flights'));

  $('btnScrollTop').addEventListener('click', () => scrollToId('top'));

  /* Swap origin <-> destination using the airport list for the city mapping. */
  $('btnSwap').addEventListener('click', () => {
    const fromLicense = $('searchFrom').value;
    const toCity = $('searchTo').value.trim();

    const originAirport = state.airports.find((a) => a.airport_license === fromLicense);
    const targetAirport = state.airports.find((a) => a.city.toLowerCase() === toCity.toLowerCase());

    if (!originAirport && !toCity) {
      toast('Fill in an origin or a destination first, then swap.', 'info');
      return;
    }
    if (toCity && !targetAirport) {
      toast(`Cannot swap: "${toCity}" is not one of the airports in the database.`, 'error');
      return;
    }
    $('searchFrom').value = targetAirport ? targetAirport.airport_license : '';
    $('searchTo').value = originAirport ? originAirport.city : '';
    toast('Origin and destination swapped.', 'info', 2400);
  });

  /* Quick filter chips. Today / Tomorrow / Scheduled are server-side filters,
     Under ₹6,000 and International are applied to the fetched rows. */
  document.querySelectorAll('.qchip').forEach((chip) => {
    chip.addEventListener('click', () => {
      const kind = chip.dataset.quick;
      const alreadyActive = chip.classList.contains('active');
      document.querySelectorAll('.qchip').forEach((c) => c.classList.remove('active'));

      if (alreadyActive) {                       // clicking again turns it off
        state.quick = null;
        $('searchForm').reset();
        loadFlights();
        return;
      }
      chip.classList.add('active');
      state.quick = kind;
      $('searchForm').reset();

      if (kind === 'today') $('searchDate').value = isoDate(0);
      if (kind === 'tomorrow') $('searchDate').value = isoDate(1);
      if (kind === 'scheduled') $('searchStatus').value = 'Scheduled';
      loadFlights();
    });
  });

  /* Sorting is done in the browser on the rows the server already returned. */
  $('sortSelect').addEventListener('change', (event) => {
    state.sort = event.target.value;
    renderFlights(state.flights);
  });
}

function clearQuickFilter() {
  state.quick = null;
  document.querySelectorAll('.qchip').forEach((chip) => chip.classList.remove('active'));
}

function wireSearchTabs() {
  document.querySelectorAll('.search-tab').forEach((tab) => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.search-tab').forEach((other) => {
        other.classList.toggle('active', other === tab);
        other.setAttribute('aria-selected', String(other === tab));
      });
      scrollToId(tab.dataset.target);
      if (tab.dataset.target === 'reports') { loadReports(); loadStats(); }
    });
  });

  $('btnNavSearch').addEventListener('click', () => {
    scrollToId('top');
    $('searchTo').focus();
  });
}

function scrollToId(id) {
  const target = $(id);
  if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/** Builds the query string for GET /api/flights from the search card. */
function flightQuery() {
  const params = new URLSearchParams();
  const from = $('searchFrom').value;
  const to = $('searchTo').value.trim();
  const date = $('searchDate').value;
  const text = $('searchText').value.trim();
  const status = $('searchStatus').value;

  if (from) params.set('source', from);
  if (to) params.set('destination', to);
  if (date) params.set('date', date);
  if (text) params.set('q', text);
  if (status) params.set('status', status);
  return params.toString();
}

async function loadFlights() {
  const tbody = $('flightsBody');
  loadingRow(tbody, 10, 'Loading flight schedule\u2026');

  try {
    const query = flightQuery();
    const { data } = await api('/api/flights' + (query ? '?' + query : ''));
    state.flights = data;
    renderFlights(data);
    updateSearchSummary(data.length);
  } catch (error) {
    $('flightsCount').textContent = '0 flights';
    loadingRow(tbody, 10, 'Could not load flights: ' + error.message);
  }
}

/** Applies the client-side quick filter, the sort order and paints the table. */
function renderFlights(rows) {
  const tbody = $('flightsBody');
  let list = [...rows];

  if (state.quick === 'cheap') list = list.filter((flight) => Number(flight.fare) <= state.maxFare);
  if (state.quick === 'intl') list = list.filter((flight) => state.intlCities.includes(flight.destination));

  const sorters = {
    departure: (a, b) => String(a.departure_time).localeCompare(String(b.departure_time)),
    fare: (a, b) => Number(a.fare) - Number(b.fare),
    seats: (a, b) => Number(b.seats_available) - Number(a.seats_available)
  };
  list.sort(sorters[state.sort] || sorters.departure);

  $('flightsCount').textContent = `${list.length} flight${list.length === 1 ? '' : 's'}`;
  $('resultsSub').textContent = state.quick
    ? `Filtered by "${quickLabel(state.quick)}" \u00b7 ${list.length} of ${rows.length} flights shown`
    : 'Live seat availability computed from the booking table';

  if (!list.length) {
    loadingRow(tbody, 10, 'No flights match this search. Try clearing the filters.');
    return;
  }

  tbody.innerHTML = list.map((flight) => {
    const lowOnSeats = Number(flight.seats_available) <= 5;
    const bookable = ['Scheduled', 'Delayed'].includes(flight.status) && Number(flight.seats_available) > 0;

    return `
      <tr>
        <td>
          <span class="flight-code">${esc(flight.flight_id)}</span>
          <div class="sub">${esc(flight.flight_name)}</div>
        </td>
        <td>
          ${esc(flight.company_name)}
          <div class="sub">${esc(flight.model)} &middot; ${esc(flight.type_of_airplane)}</div>
        </td>
        <td class="route">
          ${esc(flight.source_city)} <span class="sub">(${esc(flight.airport_license)})</span>
          <div class="sub"><span class="route-arrow">&rarr;</span> ${esc(flight.destination)}</div>
        </td>
        <td>
          ${prettyDate(flight.departure_time)}
          <div class="sub">${esc(flight.departure_hm)} hrs</div>
        </td>
        <td>${prettyTime(flight.arrival_time)}</td>
        <td>${esc(flight.duration_minutes)} min</td>
        <td>${badge(flight.status)}</td>
        <td class="num ${lowOnSeats ? 'seats-low' : 'seats-ok'}">
          ${esc(flight.seats_available)}
          <div class="sub">of ${esc(flight.capacity)}</div>
        </td>
        <td class="num">${money(flight.fare)}</td>
        <td>
          <button class="btn-book" data-book="${esc(flight.flight_id)}" ${bookable ? '' : 'disabled'}>
            ${bookable ? 'Book' : 'Closed'}
          </button>
        </td>
      </tr>`;
  }).join('');

  tbody.querySelectorAll('[data-book]').forEach((button) => {
    button.addEventListener('click', () => openBookingModal(button.dataset.book));
  });
}

const quickLabel = (kind) => ({
  today: 'Departing today', tomorrow: 'Departing tomorrow', scheduled: 'Scheduled only',
  cheap: `Fare under ${money(state.maxFare)}`, intl: 'International destinations'
}[kind] || kind);

/** One-line summary under the search card. */
function updateSearchSummary(count) {
  const from = $('searchFrom');
  const fromLabel = from.value ? from.options[from.selectedIndex].textContent.split('(')[0].trim() : 'Any airport';
  const to = $('searchTo').value.trim() || 'anywhere';
  const when = $('searchDate').value ? prettyDate($('searchDate').value) : 'all dates';
  $('searchSummary').textContent = `${count} flight${count === 1 ? '' : 's'} \u00b7 ${fromLabel} to ${to} \u00b7 ${when}`;
}

/* ==========================================================================
   §4  DEALS & OFFERS  (values computed live from the flight table)
   ========================================================================== */

function renderDeals() {
  const flights = state.flights;
  if (!flights.length) return;

  const cheap = flights.filter((flight) => Number(flight.fare) <= state.maxFare);
  const cheapestFare = Math.min(...cheap.map((flight) => Number(flight.fare)));
  const today = flights.filter((flight) => String(flight.departure_time).startsWith(isoDate(0)));
  const intl = flights.filter((flight) => state.intlCities.includes(flight.destination));

  $('dealsRow').innerHTML = `
    <article class="deal-card">
      <div class="deal-badge tone-orange">
        <span>FROM</span><b>${money(cheapestFare).replace('\u20B9', '\u20B9')}</b>
      </div>
      <div class="deal-body">
        <h4>Lowest fare available</h4>
        <p>${cheap.length} scheduled flight${cheap.length === 1 ? '' : 's'} under ${money(state.maxFare)}</p>
      </div>
      <button class="apply-pill" type="button" data-deal="cheap">Apply</button>
    </article>

    <article class="deal-card">
      <div class="deal-badge tone-blue">
        <span>TODAY</span><b>${today.length}</b>
      </div>
      <div class="deal-body">
        <h4>Departing today</h4>
        <p>Book before the departure time closes the flight</p>
      </div>
      <button class="apply-pill" type="button" data-deal="today">Apply</button>
    </article>

    <article class="deal-card">
      <div class="deal-badge tone-red">
        <span>UP TO</span><b>${intl.length}</b>
      </div>
      <div class="deal-body">
        <h4>International destinations</h4>
        <p>${state.intlCities.join(', ')}</p>
      </div>
      <button class="apply-pill" type="button" data-deal="intl">Apply</button>
    </article>`;

  $('dealsRow').querySelectorAll('[data-deal]').forEach((button) => {
    button.addEventListener('click', () => {
      const kind = button.dataset.deal;
      document.querySelectorAll('.qchip').forEach((chip) =>
        chip.classList.toggle('active', chip.dataset.quick === kind));
      state.quick = kind;
      $('searchForm').reset();
      if (kind === 'today') $('searchDate').value = isoDate(0);
      loadFlights().then(() => scrollToId('flights'));
    });
  });
}

/* ==========================================================================
   §5  HEADER ACTIONS + HELP CHAT
   ========================================================================== */

function wireHeaderActions() {
  $('btnMyTrips').addEventListener('click', () => {
    scrollToId('bookings');
    if (!$('bookingsBody').textContent.includes('Portal') && !$('lookupEmail').value) {
      // first visit: show everything so the count is not misleading
      if (/Search above to load/.test($('bookingsBody').textContent)) loadBookings();
    }
  });

  $('btnLogin').addEventListener('click', () => {
    toast('Authentication is outside the scope of this project \u2014 an app_user table with roles is listed under future scope.',
      'info', 6000);
  });

  $('btnCurrency').addEventListener('click', () => {
    toast('All fares are stored and displayed in Indian Rupees (\u20B9).', 'info', 3500);
  });

  // Round-trip needs multi-leg support, which this single-leg schema does not have.
  document.querySelectorAll('.trip-pill').forEach((pill) => {
    pill.addEventListener('click', () => {
      if (pill.dataset.trip === 'roundtrip') {
        pill.classList.add('shake');
        setTimeout(() => pill.classList.remove('shake'), 420);
        toast('Round-trip itineraries need multi-leg support (flight instances by date) \u2014 listed under future scope. One-way search stays active.',
          'info', 6500);
        return;
      }
      document.querySelectorAll('.trip-pill').forEach((other) => other.classList.toggle('active', other === pill));
    });
  });
}

function wireChat() {
  const bubble = $('chatBubble');
  const popover = $('chatPopover');

  bubble.addEventListener('click', (event) => {
    event.stopPropagation();
    popover.hidden = !popover.hidden;
  });
  popover.addEventListener('click', (event) => event.stopPropagation());
  document.addEventListener('click', () => { popover.hidden = true; });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') popover.hidden = true; });
}

/* ==========================================================================
   §6  BOOKING MODAL  (the ACID transaction runs on the server)
   ========================================================================== */

let selectedFlight = null;
let selectedSeat = null;

function wireBookingModal() {
  $('modalClose').addEventListener('click', closeBookingModal);
  $('btnCancelBooking').addEventListener('click', closeBookingModal);
  $('modalBackdrop').addEventListener('click', (event) => {
    if (event.target === $('modalBackdrop')) closeBookingModal();
  });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeBookingModal(); });
  $('bookingForm').addEventListener('submit', submitBooking);
}

/** Clears the input fields only - leaves any boarding pass / alert on screen. */
function resetBookingInputs() {
  $('bookingForm').reset();          // passenger fields cleared, payment back to UPI
  selectedSeat = null;
  $('bookingForm').style.display = '';
  $('btnConfirmBooking').disabled = false;
  $('btnConfirmBooking').textContent = 'Confirm & Pay';
}

/** Full clean slate, used every time the modal is opened. */
function resetBookingForm() {
  $('bookingResult').innerHTML = '';
  resetBookingInputs();
  // form.reset() restores inputs to their default (empty) value, so the fare has
  // to be written into the readonly amount box AFTER the reset.
  $('paymentAmount').value = selectedFlight ? money(selectedFlight.fare) : '';
}

async function openBookingModal(flightId) {
  try {
    const flight = state.flights.find((item) => item.flight_id === flightId)
      || (await api(`/api/flights/${encodeURIComponent(flightId)}`)).data;

    selectedFlight = flight;
    resetBookingForm();

    $('modalTitle').textContent = `Book seat on ${flight.flight_id}`;
    $('flightSummary').innerHTML = `
      <div><span>Flight</span><p>${esc(flight.flight_id)}</p></div>
      <div><span>Airline</span><p>${esc(flight.company_name)}</p></div>
      <div><span>Aircraft</span><p>${esc(flight.model)}</p></div>
      <div><span>Route</span><p>${esc(flight.source_city)} &rarr; ${esc(flight.destination)}</p></div>
      <div><span>Departure</span><p>${prettyDateTime(flight.departure_time)}</p></div>
      <div><span>Status</span><p>${badge(flight.status)}</p></div>`;

    $('modalBackdrop').classList.add('open');
    await loadSeatMap(flight.flight_id);
  } catch (error) {
    toast('Could not open the booking window: ' + error.message, 'error');
  }
}

function closeBookingModal() {
  $('modalBackdrop').classList.remove('open');
}

/** Draws the cabin: 6 seats per row (A-F), rows = capacity / 6. */
async function loadSeatMap(flightId) {
  const map = $('seatMap');
  map.innerHTML = '<p class="empty">Loading seat map\u2026</p>';

  try {
    const { data } = await api(`/api/flights/${encodeURIComponent(flightId)}/seats`);
    const taken = new Set(data.booked_seats);
    const rows = Math.ceil(data.capacity / 6);
    const letters = ['A', 'B', 'C', 'D', 'E', 'F'];

    $('seatHint').textContent = `\u2014 ${data.seats_available} of ${data.capacity} seats available`;

    let html = '<div class="row-label"></div>' + letters.map((letter, index) =>
      `${index === 3 ? '<div class="aisle"></div>' : ''}<div class="col-label">${letter}</div>`).join('');

    for (let row = 1; row <= rows; row++) {
      html += `<div class="row-label">${row}</div>`;
      letters.forEach((letter, index) => {
        const seat = `${row}${letter}`;
        const isTaken = taken.has(seat);
        if (index === 3) html += '<div class="aisle"></div>';
        html += `<button type="button" class="seat${isTaken ? ' taken' : ''}"
                   data-seat="${seat}" ${isTaken ? 'disabled' : ''}
                   title="${isTaken ? 'Seat ' + seat + ' is already booked' : 'Select seat ' + seat}">${seat}</button>`;
      });
    }

    map.innerHTML = html;

    map.querySelectorAll('.seat:not(.taken)').forEach((button) => {
      button.addEventListener('click', () => {
        map.querySelectorAll('.seat.selected').forEach((node) => node.classList.remove('selected'));
        button.classList.add('selected');
        selectedSeat = button.dataset.seat;
      });
    });
  } catch (error) {
    map.innerHTML = `<p class="empty">Seat map unavailable: ${esc(error.message)}</p>`;
  }
}

/** POST /api/bookings - one SQL transaction writes booking, ticket and payment. */
async function submitBooking(event) {
  event.preventDefault();
  if (!selectedFlight) return;

  const resultBox = $('bookingResult');
  const button = $('btnConfirmBooking');

  if (!selectedSeat) {
    renderAlert(resultBox, 'error', 'Please choose a seat', 'Click any white seat on the cabin map above.');
    toast('Select a seat before confirming.', 'error');
    return;
  }

  button.disabled = true;
  button.textContent = 'Processing transaction\u2026';
  resultBox.innerHTML = '';

  const payload = {
    flightId: selectedFlight.flight_id,
    seatNumber: selectedSeat,
    paymentType: $('paymentType').value,
    passenger: {
      name: $('paxName').value.trim(),
      email: $('paxEmail').value.trim(),
      phone: $('paxPhone').value.trim()
    }
  };

  try {
    const { data, message, transaction } = await api('/api/bookings', { method: 'POST', body: payload });

    $('bookingForm').style.display = 'none';
    $('bookingResult').innerHTML = `
      <div class="ticket-card">
        <div class="ticket-head">
          <h3>Booking confirmed</h3>
          <span class="ticket-brand">SkyLedger airlines &middot; Boarding pass</span>
        </div>

        <div class="ticket-grid">
          <div><span>PNR / Booking ID</span><p>#${esc(data.booking_id)}</p></div>
          <div><span>Ticket Number</span><p>${esc(data.ticket_number)}</p></div>
          <div><span>Transaction ID</span><p>${esc(data.transaction_id)}</p></div>
          <div><span>Passenger</span><p>${esc(data.passenger_name)}</p></div>
          <div><span>Flight</span><p>${esc(data.flight_id)} &middot; ${esc(data.flight_name)}</p></div>
          <div><span>Route</span><p>${esc(data.source_city)} &rarr; ${esc(data.destination)}</p></div>
          <div><span>Departure</span><p>${prettyDateTime(data.departure_time)}</p></div>
          <div><span>Boarding Time</span><p>${prettyDateTime(data.boarding_time)}</p></div>
          <div><span>Terminal</span><p>${esc(data.terminal)}</p></div>
          <div><span>Seat Number</span><p>${esc(data.seat_number)}</p></div>
          <div><span>Paid via</span><p>${esc(data.payment_type)}</p></div>
          <div><span>Amount Paid</span><p>${money(data.amount)}</p></div>
        </div>

        <p class="ticket-note">${esc(transaction && transaction.note ? transaction.note : message)}</p>

        <div class="ticket-actions">
          <button class="pill-black btn-sm" id="btnBookAnother" type="button">Book another seat</button>
          <button class="pill-outline btn-sm" id="btnSeeBookings" type="button">View in Manage Booking</button>
        </div>
      </div>`;

    $('btnBookAnother').addEventListener('click', () => openBookingModal(selectedFlight.flight_id));
    $('btnSeeBookings').addEventListener('click', () => {
      closeBookingModal();
      $('lookupEmail').value = data.email;
      $('lookupBookingId').value = '';
      loadBookings();
      scrollToId('bookings');
    });

    toast(message, 'success', 6000);
    resetBookingInputs();                     // clean inputs, keep the boarding pass
    $('bookingForm').style.display = 'none';

    await Promise.all([loadFlights(), loadStats(), loadReports(), checkHealth()]);
    renderDeals();
  } catch (error) {
    // Stay in the modal and show exactly what the database refused. The typed
    // passenger details are kept so only the seat choice has to be repeated.
    renderAlert(resultBox, 'error', error.message,
      error.status === 409
        ? 'That seat was taken by another passenger, or the flight is closed for booking. Please choose a different seat.'
        : (error.details ? 'Details: ' + JSON.stringify(error.details) : ''));

    toast(error.message, 'error', 7000);
    selectedSeat = null;
    $('btnConfirmBooking').disabled = false;
    $('btnConfirmBooking').textContent = 'Confirm & Pay';
    if (selectedFlight) await loadSeatMap(selectedFlight.flight_id);
  } finally {
    button.disabled = false;
    button.textContent = 'Confirm & Pay';
  }
}

/* ==========================================================================
   §7  MANAGE BOOKING
   ========================================================================== */

function wireManageBooking() {
  $('bookingsForm').addEventListener('submit', (event) => {
    event.preventDefault();
    loadBookings();
  });

  $('btnAllBookings').addEventListener('click', () => {
    $('lookupEmail').value = '';
    $('lookupBookingId').value = '';
    loadBookings();
  });

  $('bookingsBody').addEventListener('click', async (event) => {
    const button = event.target.closest('[data-cancel]');
    if (!button) return;

    const bookingId = button.dataset.cancel;
    if (!confirm(`Cancel booking #${bookingId}?\n\nThe seat will be released and the payment marked as refunded.`)) return;

    button.disabled = true;
    button.textContent = 'Cancelling\u2026';
    try {
      const { message } = await api(`/api/bookings/${encodeURIComponent(bookingId)}/cancel`, { method: 'PATCH' });
      toast(message, 'success');
      await Promise.all([loadBookings(), loadFlights(), loadStats(), loadReports()]);
      renderDeals();
    } catch (error) {
      toast('Cancel failed: ' + error.message, 'error');
      button.disabled = false;
      button.textContent = 'Cancel';
    }
  });
}

async function loadBookings() {
  const tbody = $('bookingsBody');
  const email = $('lookupEmail').value.trim();
  const bookingId = $('lookupBookingId').value.trim();

  loadingRow(tbody, 12, 'Loading reservations\u2026');

  try {
    let rows;
    if (bookingId) {
      rows = [(await api(`/api/bookings/${encodeURIComponent(bookingId)}`)).data];
    } else {
      // no email -> the API returns every reservation, which is what the
      // dashboard should show on first load
      rows = (await api('/api/bookings' + (email ? '?email=' + encodeURIComponent(email) : ''))).data;
    }

    $('bookingsCount').textContent = `${rows.length} reservation${rows.length === 1 ? '' : 's'}`;

    if (!rows.length) {
      loadingRow(tbody, 12, 'No reservations found. Check the email address, or press "Show All".');
      return;
    }

    tbody.innerHTML = rows.map((booking) => {
      const cancellable = ['Confirmed', 'Pending'].includes(booking.booking_status)
        && !['Departed', 'Arrived', 'Cancelled'].includes(booking.flight_status);

      return `
        <tr>
          <td>#${esc(booking.booking_id)}<div class="sub">${prettyDate(booking.booking_date)}</div></td>
          <td>
            ${esc(booking.passenger_name)}
            <div class="sub">${esc(booking.email)}<br />${esc(booking.phone_number)}</div>
          </td>
          <td><span class="flight-code">${esc(booking.flight_id)}</span><div class="sub">${esc(booking.flight_name)}</div></td>
          <td class="route">${esc(booking.source_city)} <span class="route-arrow">&rarr;</span> ${esc(booking.destination)}</td>
          <td>${prettyDateTime(booking.departure_time)}</td>
          <td><strong>${esc(booking.seat_number)}</strong></td>
          <td>${booking.ticket_number ? esc(booking.ticket_number) : '<span class="sub">not issued</span>'}</td>
          <td>
            ${booking.terminal ? esc(booking.terminal) : '\u2014'}
            <div class="sub">${booking.boarding_time ? prettyTime(booking.boarding_time) : ''}</div>
          </td>
          <td>
            ${booking.payment_type ? esc(booking.payment_type) : '\u2014'}
            ${booking.payment_status ? badge(booking.payment_status) : ''}
            <div class="sub">${booking.transaction_id ? esc(booking.transaction_id) : ''}</div>
          </td>
          <td class="num">${booking.amount != null ? money(booking.amount) : '\u2014'}</td>
          <td>${badge(booking.booking_status)}</td>
          <td>${cancellable ? `<button class="btn-cancel" data-cancel="${esc(booking.booking_id)}">Cancel</button>` : ''}</td>
        </tr>`;
    }).join('');
  } catch (error) {
    $('bookingsCount').textContent = '0 reservations';
    loadingRow(tbody, 12, 'Could not load reservations: ' + error.message);
  }
}

/* ==========================================================================
   §8  STATS & REPORTS
   ========================================================================== */

async function loadStats() {
  try {
    const { data } = await api('/api/stats/dashboard');
    const summary = data.summary;

    $('statFlights').textContent = summary.total_flights;
    $('statFlightsFoot').textContent = `${summary.flights_today} departing today`;
    $('statSeats').textContent = Number(summary.seats_available).toLocaleString('en-IN');
    $('statBookings').textContent = summary.active_bookings;
    $('statBookingsFoot').textContent = `${summary.cancelled_bookings} cancelled`;
    $('statRevenue').textContent = money(summary.revenue_collected);
    $('statRevenueFoot').textContent = `${money(summary.revenue_refunded)} refunded`;
    $('statPassengers').textContent = summary.total_passengers;
    $('statPilots').textContent = `${summary.total_pilots} / ${summary.total_companies}`;
    $('statPilotsFoot').textContent = `pilot / airline \u00B7 ${summary.total_airports} airports`;

    $('tripCount').textContent = summary.active_bookings;
    $('footerStats').textContent =
      `${summary.total_airports} airports \u00B7 ${summary.total_companies} airlines \u00B7 ` +
      `${summary.total_pilots} pilots \u00B7 ${summary.total_flights} flights \u00B7 ${summary.active_bookings} bookings`;

    $('summaryGrid').innerHTML = [
      ['Airports', summary.total_airports],
      ['Airlines', summary.total_companies],
      ['Pilots', summary.total_pilots],
      ['Flights', summary.total_flights],
      ['Scheduled', summary.scheduled_flights],
      ['Flights today', summary.flights_today],
      ['Passengers', summary.total_passengers],
      ['Active bookings', summary.active_bookings],
      ['Cancelled', summary.cancelled_bookings],
      ['Seats available', Number(summary.seats_available).toLocaleString('en-IN')],
      ['Revenue collected', money(summary.revenue_collected)],
      ['Revenue refunded', money(summary.revenue_refunded)]
    ].map(([label, value]) =>
      `<div class="summary-item"><span>${esc(label)}</span><p>${esc(value)}</p></div>`).join('');
  } catch (error) {
    console.warn('Could not load statistics:', error.message);
  }
}

function wireReports() {
  $('btnRefreshReports').addEventListener('click', async () => {
    await Promise.all([loadReports(), loadStats()]);
    toast('Reports refreshed.', 'info', 2200);
  });
}

async function loadReports() {
  try {
    const { data } = await api('/api/stats/dashboard');

    const maxRevenue = Math.max(...data.revenue_by_airline.map((row) => Number(row.revenue)), 1);
    $('revenueBody').innerHTML = data.revenue_by_airline.map((row) => `
      <tr>
        <td>${esc(row.company_name)}<div class="sub">${esc(row.model)}</div></td>
        <td class="num">${esc(row.flights)}</td>
        <td class="num">${esc(row.bookings)}</td>
        <td class="num">${money(row.revenue)}
          <div class="bar"><i style="width:${Math.round((Number(row.revenue) / maxRevenue) * 100)}%"></i></div>
        </td>
      </tr>`).join('');

    $('occupancyBody').innerHTML = data.top_occupancy.map((flight) => `
      <tr>
        <td><span class="flight-code">${esc(flight.flight_id)}</span><div class="sub">${esc(flight.flight_name)}</div></td>
        <td class="route">${esc(flight.source_city)} <span class="route-arrow">&rarr;</span> ${esc(flight.destination)}</td>
        <td class="num">${esc(flight.seats_available)} / ${esc(flight.capacity)}</td>
        <td class="num">${esc(flight.occupancy_percent ?? 0)} %
          <div class="bar"><i style="width:${Math.min(Number(flight.occupancy_percent) || 0, 100)}%"></i></div>
        </td>
      </tr>`).join('');
  } catch (error) {
    console.warn('Could not load reports:', error.message);
    loadingRow($('revenueBody'), 4, 'Reports unavailable: ' + error.message);
  }
}
