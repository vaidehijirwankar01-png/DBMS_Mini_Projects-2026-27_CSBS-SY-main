from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path
from datetime import date, timedelta

app = Flask(__name__)
app.secret_key = "ironpulse-demo-secret-change-me"

DB_PATH = Path(__file__).with_name("gym.db")


# ---------------- DATABASE CONNECTION ----------------

def connect_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


# ---------------- CREATE DATABASE TABLES ----------------

def init_db():
    with connect_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS plans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            price REAL NOT NULL CHECK(price >= 0),
            duration_months INTEGER NOT NULL CHECK(duration_months > 0),
            description TEXT DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS members (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            phone TEXT NOT NULL,
            email TEXT,
            gender TEXT,
            address TEXT,
            fitness_goal TEXT,
            plan_id INTEGER,
            joined_on TEXT NOT NULL,
            expires_on TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Active',
            FOREIGN KEY(plan_id) REFERENCES plans(id)
                ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            member_id INTEGER NOT NULL,
            amount REAL NOT NULL CHECK(amount >= 0),
            payment_date TEXT NOT NULL,
            method TEXT NOT NULL DEFAULT 'Cash',
            status TEXT NOT NULL DEFAULT 'Paid',
            receipt_no TEXT NOT NULL UNIQUE,
            FOREIGN KEY(member_id) REFERENCES members(id)
                ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            member_id INTEGER NOT NULL,
            check_in TEXT NOT NULL,
            notes TEXT DEFAULT '',
            FOREIGN KEY(member_id) REFERENCES members(id)
                ON DELETE CASCADE
        );
        """)

        # Insert default membership plans only once
        count = db.execute(
            "SELECT COUNT(*) FROM plans"
        ).fetchone()[0]

        if count == 0:
            db.executemany("""
                INSERT INTO plans
                (name, price, duration_months, description)
                VALUES (?, ?, ?, ?)
            """, [
                ("Basic", 1000, 1, "Gym access"),
                ("Standard", 2700, 3, "Gym and fitness assessment"),
                ("Premium", 5000, 6, "Gym and trainer consultation")
            ])


# ---------------- DASHBOARD ----------------

@app.route("/")
def dashboard():
    with connect_db() as db:
        total_members = db.execute(
            "SELECT COUNT(*) FROM members"
        ).fetchone()[0]

        active_members = db.execute("""
            SELECT COUNT(*) FROM members
            WHERE status = 'Active'
            AND expires_on >= ?
        """, (date.today().isoformat(),)).fetchone()[0]

        total_revenue = db.execute("""
            SELECT COALESCE(SUM(amount), 0)
            FROM payments
            WHERE status = 'Paid'
        """).fetchone()[0]

        members = db.execute("""
            SELECT m.*, p.name AS plan_name
            FROM members m
            LEFT JOIN plans p ON p.id = m.plan_id
            ORDER BY m.id DESC
        """).fetchall()

        recent_payments = db.execute("""
            SELECT py.*, m.full_name
            FROM payments py
            JOIN members m ON m.id = py.member_id
            ORDER BY py.id DESC
            LIMIT 5
        """).fetchall()

    return render_template(
        "dashboard.html",
        total_members=total_members,
        active_members=active_members,
        total_revenue=total_revenue,
        members=members,
        recent_payments=recent_payments
    )


# ---------------- VIEW ALL MEMBERS ----------------

@app.route("/members")
def members_page():
    with connect_db() as db:
        members = db.execute("""
            SELECT m.*, p.name AS plan_name
            FROM members m
            LEFT JOIN plans p ON p.id = m.plan_id
            ORDER BY m.id DESC
        """).fetchall()

    return render_template("members.html", members=members)


# ---------------- ADD MEMBER ----------------

@app.route("/members/add", methods=["GET", "POST"])
def add_member():
    with connect_db() as db:
        plans = db.execute(
            "SELECT * FROM plans ORDER BY price"
        ).fetchall()

        if request.method == "POST":
            name = request.form.get("full_name", "").strip()
            phone = request.form.get("phone", "").strip()
            email = request.form.get("email", "").strip()
            gender = request.form.get("gender", "")
            address = request.form.get("address", "").strip()
            goal = request.form.get("fitness_goal", "").strip()
            plan_id = request.form.get("plan_id") or None
            joined = request.form.get(
                "joined_on", date.today().isoformat()
            )

            if not name or not phone:
                flash("Name and phone are required.", "error")
                return render_template(
                    "member_form.html", plans=plans
                )

            try:
                joined_date = date.fromisoformat(joined)
            except ValueError:
                flash("Invalid joining date.", "error")
                return render_template(
                    "member_form.html", plans=plans
                )

            plan = None
            if plan_id:
                plan = db.execute(
                    "SELECT * FROM plans WHERE id = ?",
                    (plan_id,)
                ).fetchone()

                if not plan:
                    flash("Invalid membership plan.", "error")
                    return render_template(
                        "member_form.html", plans=plans
                    )

            duration = plan["duration_months"] if plan else 1
            expires = joined_date + timedelta(days=duration * 30)

            cursor = db.execute("""
                INSERT INTO members (
                    full_name, phone, email, gender, address,
                    fitness_goal, plan_id, joined_on, expires_on,
                    status
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                name, phone, email, gender, address, goal,
                plan_id, joined, expires.isoformat(), "Active"
            ))

            member_id = cursor.lastrowid

            if plan:
                receipt = (
                    f"IP-{date.today().year}-{member_id:04d}"
                )
                db.execute("""
                    INSERT INTO payments (
                        member_id, amount, payment_date,
                        method, status, receipt_no
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    member_id, plan["price"], joined,
                    request.form.get("method", "Cash"),
                    "Paid", receipt
                ))

            flash("Member added successfully.", "success")
            return redirect(
                url_for("member_detail", member_id=member_id)
            )

    return render_template("member_form.html", plans=plans)


# ---------------- MEMBER PROFILE ----------------

@app.route("/members/<int:member_id>")
def member_detail(member_id):
    with connect_db() as db:
        member = db.execute("""
            SELECT m.*, p.name AS plan_name,
                   p.price AS plan_price,
                   p.duration_months
            FROM members m
            LEFT JOIN plans p ON p.id = m.plan_id
            WHERE m.id = ?
        """, (member_id,)).fetchone()

        if not member:
            flash("Member not found.", "error")
            return redirect(url_for("members_page"))

        payments = db.execute("""
            SELECT * FROM payments
            WHERE member_id = ?
            ORDER BY payment_date DESC, id DESC
        """, (member_id,)).fetchall()

        attendance = db.execute("""
            SELECT * FROM attendance
            WHERE member_id = ?
            ORDER BY check_in DESC
            LIMIT 20
        """, (member_id,)).fetchall()

        total_paid = db.execute("""
            SELECT COALESCE(SUM(amount), 0)
            FROM payments
            WHERE member_id = ? AND status = 'Paid'
        """, (member_id,)).fetchone()[0]

        plans = db.execute(
            "SELECT * FROM plans ORDER BY price"
        ).fetchall()

    return render_template(
        "member_detail.html",
        member=member,
        payments=payments,
        attendance=attendance,
        total_paid=total_paid,
        plans=plans
    )


# ---------------- CHANGE MEMBERSHIP PLAN ----------------

@app.route("/members/<int:member_id>/plan", methods=["POST"])
def change_plan(member_id):
    plan_id = request.form.get("plan_id")

    with connect_db() as db:
        member = db.execute(
            "SELECT * FROM members WHERE id = ?",
            (member_id,)
        ).fetchone()

        plan = db.execute(
            "SELECT * FROM plans WHERE id = ?",
            (plan_id,)
        ).fetchone() if plan_id else None

        if not member or not plan:
            flash("Invalid member or membership plan.", "error")
            return redirect(url_for("dashboard"))

        today = date.today()
        expiry = today + timedelta(
            days=plan["duration_months"] * 30
        )

        db.execute("""
            UPDATE members
            SET plan_id = ?, joined_on = ?, expires_on = ?,
                status = 'Active'
            WHERE id = ?
        """, (
            plan["id"], today.isoformat(),
            expiry.isoformat(), member_id
        ))

        receipt = (
            f"IP-{today.year}-{member_id:04d}-{today.strftime('%m%d')}"
        )

        # Ensure each receipt number remains unique
        receipt += f"-{db.execute('SELECT COUNT(*) FROM payments WHERE member_id = ?', (member_id,)).fetchone()[0] + 1}"

        db.execute("""
            INSERT INTO payments (
                member_id, amount, payment_date,
                method, status, receipt_no
            )
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            member_id, plan["price"], today.isoformat(),
            request.form.get("method", "UPI"),
            "Paid", receipt
        ))

    flash("Membership updated successfully.", "success")
    return redirect(
        url_for("member_detail", member_id=member_id)
    )


# ---------------- RECORD ATTENDANCE ----------------

@app.route(
    "/members/<int:member_id>/attendance",
    methods=["POST"]
)
def check_in(member_id):
    with connect_db() as db:
        member = db.execute("""
            SELECT id, expires_on, status
            FROM members WHERE id = ?
        """, (member_id,)).fetchone()

        if not member:
            flash("Member not found.", "error")
            return redirect(url_for("members_page"))

        if member["status"] != "Active" or member["expires_on"] < date.today().isoformat():
            flash("Membership has expired or is inactive.", "error")
            return redirect(
                url_for("member_detail", member_id=member_id)
            )

        check_time = request.form.get("time", "09:00")
        notes = request.form.get("notes", "").strip()

        db.execute("""
            INSERT INTO attendance (member_id, check_in, notes)
            VALUES (?, ?, ?)
        """, (
            member_id,
            date.today().isoformat() + " " + check_time,
            notes
        ))

    flash("Attendance recorded.", "success")
    return redirect(
        url_for("member_detail", member_id=member_id)
    )


# ---------------- DELETE MEMBER ----------------

@app.route(
    "/members/<int:member_id>/delete",
    methods=["POST"]
)
def delete_member(member_id):
    with connect_db() as db:
        db.execute(
            "DELETE FROM members WHERE id = ?",
            (member_id,)
        )

    flash("Member deleted successfully.", "success")
    return redirect(url_for("members_page"))


# ---------------- MEMBERSHIP PLANS ----------------

@app.route("/plans")
def plans_page():
    with connect_db() as db:
        plans = db.execute("""
            SELECT p.*, COUNT(m.id) AS member_count
            FROM plans p
            LEFT JOIN members m ON m.plan_id = p.id
            GROUP BY p.id
            ORDER BY p.price
        """).fetchall()

    return render_template("plans.html", plans=plans)


# ---------------- PAYMENT HISTORY ----------------

@app.route("/payments")
def payments_page():
    with connect_db() as db:
        payments = db.execute("""
            SELECT py.*, m.full_name
            FROM payments py
            JOIN members m ON m.id = py.member_id
            ORDER BY py.payment_date DESC, py.id DESC
        """).fetchall()

        total = db.execute("""
            SELECT COALESCE(SUM(amount), 0)
            FROM payments
            WHERE status = 'Paid'
        """).fetchone()[0]

    return render_template(
        "payments.html",
        payments=payments,
        total=total
    )


# ---------------- START APPLICATION ----------------

if __name__ == "__main__":
    init_db()
    app.run(debug=True)